export const GraphData = [
    
    

    
    {

    "dx": "868",
    "dy": "494",
    "grid": "1",
    "gridSize": "10",
    "guides": "1",
    "tooltips": "1",
    "connect": "1",
    "arrows": "1",
    "fold": "1",
    "page": "1",
    "pageScale": "1",
    "pageWidth": "850",
    "pageHeight": "1100",
    "root": [{ "id": "0" }, { "id": "1", "parent": "0" },

        { "id": "27", "value": "", "style": "html=1;points=[];perimeter=orthogonalPerimeter;shadow=0;sketch=0;strokeWidth=2;fillColor=#FF4DED;gradientColor=#ffffff;rotation=90;", "vertex": "1", "parent": "1", "mxGeometry": { "x": "300", "y": "105", "width": "10", "height": "290", "as": "geometry" } }, {
            "id": "28",
            "value": "",
            "style": "shape=filledEdge;rounded=0;fixDash=1;endArrow=none;strokeWidth=10;fillColor=#ffffff;edgeStyle=orthogonalEdgeStyle;",
            "edge": "1",
            "parent": "1",
            "mxGeometry": {
                "width": "60",
                "height": "40",
                "relative": "1",
                "as": "geometry",
                "mxPoint": [{ "x": "688", "y": "575", "as": "sourcePoint" },
                    { "x": "200", "y": "90", "as": "targetPoint" }
                ],
                "Array": { "as": "points", "mxPoint": { "x": "200", "y": "90" } }
            }
        },




    ]
}];

export default GraphData;