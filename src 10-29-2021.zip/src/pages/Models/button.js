export const GraphData = [{

    "dx": "868",
    "dy": "494",
    "grid": "1",
    "gridSize": "10",
    "guides": "1",
    "tooltips": "1",
    "connect": "1",
    "arrows": "1",
    "fold": "1",
    "page": "1",
    "pageScale": "1",
    "pageWidth": "850",
    "pageHeight": "1100",
    "root": [{ "id": "0" }, { "id": "1", "parent": "0" },
        {
            "id": "31",
            "value": "Button",
            "style": "html=1;align=center;verticalAlign=top;rounded=1;absoluteArcSize=1;arcSize=10;dashed=0;fillColor=blue;gradientColor=blue;",
            "vertex": "1",
            "parent": "1",
            "mxGeometry": { "x": "205", "y": "105", "width": "140", "height": "40", "as": "geometry" }
        }

    ]
}];

export default GraphData;