import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios'


export default class ViewEvents extends Component {

    constructor(props) {
        super(props);

        this.state = {
            name: [],
            startDate: null,
            EndDate: null,
            selectedFile: null,
            searchInput: ""
        }
    }

    async componentDidMount() {
        try {
            setInterval(async () => {
                axios.get('http://localhost/ScadaClient/api/EventsAlarms').then(res => {
                    //console.log(res);
                    this.setState({ name: res.data });
                    this.setState({ selectedFile: res.data });
                });
            }, 8000);
        } catch (e) {
            console.log(e);
        }
    }
    globalSearch = () => {
        let { searchInput } = this.state;
        //console.log( this.state.selectedFile)

        let filteredData = this.state.selectedFile.filter(value => {
           // console.log(value.VALUE)
            return (
                value.pointname.toLowerCase().includes(searchInput.toLowerCase()) ||
                value.description.substring(33, 100).toLowerCase().includes(searchInput.toLowerCase()) ||
                value.description.substring(9, 21).toLowerCase().includes(searchInput.toLowerCase()) ||
                value.description.substring(0, 9).toLowerCase().includes(searchInput.toLowerCase()) ||
                value.plantloc.toLowerCase().includes(searchInput.toLowerCase())



            );
        });
        console.log(filteredData)

        this.setState({ name: filteredData });


    };
    handleChange2 = e => {
        console.log(e.target.value)
        this.setState({ searchInput: e.target.value }, () => {
            console.log("................")
            this.globalSearch();
        });
    };
    render() {
        return (
            <body className="font-montserrat">
                {/* <!-- Page Loader --> */}
                {/* <div className="page-loader-wrapper">
    <div className="loader">
    </div>
</div> */}

                <div >

                    <div className="page">

                        <div className="">

                            <div className="row clearfix">
                                <div className="col-lg-12">
                                    <div className="card">
                                        <div className="card-header">
                                            <ul class="nav nav-tabs page-header-tab">
                                                <li class="nav-item"><Link to="/ViewEvents" class="nav-link active show" data-toggle="tab" href="#Area_Charts">View Events</Link></li>

                                                <li class="nav-item" ><Link to="/HistoricEvents" class="nav-link inactive show" data-toggle="tab" href="#Area_Charts"> Historic Events</Link></li>
                          
                                            </ul>
                                            {/* <h3 className="card-title">Events</h3> */}
                                            <div className="card-options">

                                                {/* <div class="dropdown"  style={{marginRight:"34px"}}>
                                    <button  className="custom-select" id="dropbtn">View Events</button>
                                    <div class="dropdown-content">
                                       {/*  <Link to ='/ViewAlarms'>View Alarms</Link> */}
                                                {/*     <Link to="/HistoricAlarms">Historic Events</Link>  */}

                                                {/*  </div>
                                </div> */}


                                                {/* <button className="btn btn-sm btn-outline-secondary mr-1" id="one_month">1M</button>
                                                <button className="btn btn-sm btn-outline-secondary mr-1" id="six_months">6M</button>
                                                <button className="btn btn-sm btn-outline-secondary mr-1" id="one_year" class="active">1Y</button>
                                                <button className="btn btn-sm btn-outline-secondary mr-1" id="ytd">YTD</button>
                                                <button className="btn btn-sm btn-outline-secondary" id="all">ALL</button> */}
                                            </div>

                                            
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>

                        
                        <div class="row">
                            <div className="col-md-3 col-sm-12" style={{}}>
                              
                                 <input style={{ marginLeft: "1340px" }}
                                        
                                        size="large"
                                        name="searchInput"
                                        value={this.state.searchInput || ""}
                                        onChange={this.handleChange2}
                                        placeholder="Search"
                                    />

                            </div>




                        </div>


                        <div className="">

                        <div className="tab-content">
                    <div className="tab-pane fade show active" id="list" role="tabpanel">
                        <div className="row clearfix">
                            <div className="col-lg-12">
                                <div className="" id="users">
                                    <table className="table  table-vcenter text-nowrap table_custom border-style list"> 
                                        <table className="table  ">
                                        <thead style={{textAlign:"left"}}>
                                                            <tr style={{textAlign:"", backgroundColor: "#252d43" }}>
                                                                <th style={{fontSize:"18px", color:"#E5E5E5",fontWeight:'bold'}}>Date</th>
                                                                <th style={{ fontSize:"18px", color:"#E5E5E5",fontWeight:'bold' }}>Time</th>
                                                                <th style={{fontSize:"18px", color:"#E5E5E5",fontWeight:'bold'}}>Device Name</th>
                                                                <th style={{ fontSize:"18px", color:"#E5E5E5",fontWeight:'bold' }}>Tag Name</th>
                                                                <th style={{fontSize:"18px", color:"#E5E5E5",fontWeight:'bold' }}>Description</th>
                                                                <th style={{ fontSize:"18px", color:"#E5E5E5",fontWeight:'bold'}}>Alm Value</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody >
                                                            {this.state.name.map(name => (
                                                                 
                                                                <tr style={{height:"10px",textAlign:"left", backgroundColor: "#252d43" }} >
                                                                    <td className="hidden-xs" style={{ color: "#00FF00",width:20}}>
                                                                        {name.description.substring(9, 21)}
                                                                    </td>
                                                                    <td  style={{ color: "#00FF00" ,width:20 }}>
                                                                        {name.description.substring(1, 10)}
                                                                    </td>
                                                                    <td style={{ color: "#00FF00",width:20 }}>
                                                                        {name.plantloc}
                                                                    </td>
                                                                    <td  style={{ color: "#00FF00",width:20 }}>
                                                                        {name.pointname}
                                                                    </td>
                                                                    <td  style={{ color: "#00FF00" }}>
                                                                        {name.description.substring(33,77)}
                                                                    </td>
                                                                    <td style={{ color: "#00FF00" }}>
                                                                    {name.description.substring(77,)}
                                                                    </td>
                                                                </tr>
                                                               
                                                            ))}
                                                             
                                                        </tbody>
                                                    </table>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </body>
        )
    }
}