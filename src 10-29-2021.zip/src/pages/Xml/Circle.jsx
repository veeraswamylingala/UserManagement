const Circle = () => {
    return (
    
        <circle
          cx="150"
          cy="77"
          r="40"
        />
  
    )
  }

  export default Circle;