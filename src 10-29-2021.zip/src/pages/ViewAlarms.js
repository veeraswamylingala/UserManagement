import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import './ViewAlarms.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheckCircle, faWindowClose } from '@fortawesome/fontawesome-free-solid'
import Blink from 'react-blink-text';

import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import DateTimeRangeContainer from 'react-advanced-datetimerange-picker'
import { FormControl } from 'react-bootstrap'
import moment from "moment"
/* import { DateRangePicker } from 'react-dates'; */

import DatetimeRangePicker from 'react-datetime-range-picker';


export default class ViewAlarms extends Component {

    constructor(props) {
        super(props);

        this.state = {
            name: null,
            startDate: null,
            EndDate: null,
            selectedFile: null,
            searchInput: "",
        }
    }


    async componentDidMount() {
        try {
            setInterval(async () => {
                axios.get('http://localhost/ScadaClient/api/alarms').then(res => {
//console.log(res);
                    this.setState({ name: res.data });
                    this.setState({ selectedFile: res.data });

                });
            }, 8000);

            // axios.get('http://localhost/ScadaClient/api/alarms').then(res => {
            //             console.log(res);
            //             this.setState({ name: res.data });

            //         });
        } catch (e) {
            //console.log(e);
        }
    }


    checkValue(param) {
        let value = param;
        //   console.log(value);
        if (value == 0.00) {
            return "Fault";
        }
        else if (value == 1.00) {
            return "Warning";
        }
        else {
            return "Caution";
        }
    }

    checkAckStatus(param) {

        let Ack = param;
        //  console.log(Ack);
        if (Ack == 0) {
            return <FontAwesomeIcon icon={faWindowClose} />
        }
        else if (Ack == 1) {
            return <FontAwesomeIcon icon={faCheckCircle} />
        }
        else {
            return "z";
        }
    }
    globalSearch = () => {
        let { searchInput } = this.state;
        //console.log( this.state.selectedFile)

        let filteredData = this.state.selectedFile.filter(value => {
            console.log(value.VALUE)
            return (
                value.pointname.toLowerCase().includes(searchInput.toLowerCase()) ||
                value.description.substring(33, 100).toLowerCase().includes(searchInput.toLowerCase()) ||
                value.description.substring(9, 21).toLowerCase().includes(searchInput.toLowerCase()) ||
                value.description.substring(0, 9).toLowerCase().includes(searchInput.toLowerCase()) ||
                value.plantloc.toLowerCase().includes(searchInput.toLowerCase()) ||
                this.checkValue(value.value).toLowerCase().includes(searchInput.toLowerCase())



            );
        });
        console.log(filteredData)

        this.setState({ name: filteredData });


    };
    handleChange = e => {
        console.log(e.target.value)
        this.setState({ searchInput: e.target.value }, () => {
            console.log("................")
            this.globalSearch();
        });
    };

//Date value.................................................
dateTD(name) {

    if (name.ack == 0 && name.retn == 0) {
        
        return <div style={{ textTransform: "none", color: "#ED1C24" }}><Blink color='#FF0000' text= {name.description.substring(9, 21)} textColor="white"  fontSize='20'></Blink></div>

    }
    else if (name.ack == 0 && name.retn == 1) {
        return <div style={{ textTransform: "none", color: "#E5E5E5" }}>{name.description.substring(9,21)}</div>

    }
    else if (name.ack == 1 && name.retn == 0) {
        return <div style={{ textTransform: "none", color: "#FF0000" }}>{name.description.substring(9,21)}</div>

    }
    else if (name.ack == 1 && name.retn == 1) {
        return <div style={{ textTransform: "none", color: "#00FF00" }}>{name.description.substring(9,21)}</div>

    }
}

    //Time Value-----------------------------------------------------------------------
    timeTD(name) {

        if (name.ack == 0 && name.retn == 0) {
            return <div  style={{ textTransform: "none", color: "#ED1C24" }}><Blink color='#FF0000' text= {name.description.substring(0, 9)} blinkTime="100" fontSize='20'></Blink></div>

        }
        else if (name.ack == 0 && name.retn == 1) {
            return <div style={{ textTransform: "none", color: "#E5E5E5" }}>{name.description.substring(0, 9)}</div>

        }
        else if (name.ack == 1 && name.retn == 0) {
            return <div style={{ textTransform: "none", color: "#FF0000" }}>{name.description.substring(0, 9)}</div>

        }
        else if (name.ack == 1 && name.retn == 1) {
            return <div style={{ textTransform: "none", color: "#00FF00" }}>{name.description.substring(0, 9)}</div>

        }
    }


    //Device NAME----------------------------------------------------------------------------
    deviceNameTD(name) {

        if (name.ack == 0 && name.retn == 0) {
            return <div  style={{ textTransform: "none", color: "#E5E5E5" }}><Blink color='#FF0000' text= {name.plantloc} fontSize='20'></Blink></div>

        }
        else if (name.ack == 0 && name.retn == 1) {
            return <div style={{ textTransform: "none", color: "#E5E5E5" }}>{name.plantloc}</div>

        }
        else if (name.ack == 1 && name.retn == 0) {
            return <div style={{ textTransform: "none", color: "#FF0000" }}>{name.plantloc}</div>

        }
        else if (name.ack == 1 && name.retn == 1) {
            return <div style={{ textTransform: "none", color: "#00FF00" }}>{name.plantloc}</div>

        }

    }


    //TagName---------------------------------------------------------------------------
    tagNameTD(name) {
        if (name.ack == 0 && name.retn == 0) {
            return <div   style={{ textTransform: "none", color: "#E5E5E5" }}><Blink color='#FF0000' text= {name.pointname} fontSize='20'></Blink></div>

        }
        else if (name.ack == 0 && name.retn == 1) {
            return <div style={{ textTransform: "none", color: "#E5E5E5" }}>{name.pointname}</div>

        }
        else if (name.ack == 1 && name.retn == 0) {
            return <div style={{ textTransform: "none", color: "#FF0000" }}>{name.pointname}</div>

        }
        else if (name.ack == 1 && name.retn == 1) {
            return <div style={{ textTransform: "none", color: "#00FF00" }}>{name.pointname}</div>

        }
    }


    //Description--------------------------------------------------------------------------------------
    descriptionTD(name) {
        if (name.ack == 0 && name.retn == 0) {
            return <div  style={{ textTransform: "none", color: "#E5E5E5" }}><Blink color='#FF0000' text= {name.description.substring(33, 77)}  fontSize='20'></Blink></div>

        }
        else if (name.ack == 0 && name.retn == 1) {
            return <div style={{ textTransform: "none", color: "#E5E5E5" }}>{name.description.substring(33, 77)}</div>

        }
        else if (name.ack == 1 && name.retn == 0) {
            return <div style={{ textTransform: "none", color: "#FF0000" }}>{name.description.substring(33, 77)}</div>

        }
        else if (name.ack == 1 && name.retn == 1) {
            return <div style={{ textTransform: "none", color: "#00FF00" }}>{name.description.substring(33, 77)}</div>
        }
    }


    //Alm Value------------------------------------------------------------------------------------------------
    almValueTD(name) {

        if (name.ack == 0 && name.retn == 0) {
            return <div  style={{ textTransform: "none", color: "#E5E5E5" }}><Blink color='#FF0000' text= {name.description.substring(77, 100)} fontSize='20'></Blink></div>

        }
        else if (name.ack == 0 && name.retn == 1) {
            return <div style={{ textTransform: "none", color: "#E5E5E5" }}>{name.description.substring(77, 100)}</div>
        }
        else if (name.ack == 1 && name.retn == 0) {
            return <div style={{ textTransform: "none", color: "#FF0000" }}>{name.description.substring(77, 100)}</div>
        }
        else if (name.ack == 1 && name.retn == 1) {
            return <div style={{ textTransform: "none", color: "#00FF00" }}>{name.description.substring(77, 100)}</div>
        }

    }


    //Ack Status--------------------------------------------------------------------------------------------------------
    ackStatusTD(name) {

        if (name.ack == 0 && name.retn == 0) {
            return <div  style={{ textTransform: "none", color: "#E5E5E5" }}><Blink color='#FF0000' text= {this.checkAckStatus(name.ack)} fontSize='20'></Blink></div>
        }
        else if (name.ack == 0 && name.retn == 1) {
            return <div style={{ textTransform: "none", color: "#E5E5E5" }}>{this.checkAckStatus(name.ack)}</div>

        }
        else if (name.ack == 1 && name.retn == 0) {
            return <div style={{ textTransform: "none", color: "#FF0000" }}>{this.checkAckStatus(name.ack)}</div>

        }
        else if (name.ack == 1 && name.retn == 1) {
            return <div style={{ textTransform: "none", color: "#00FF00" }}>{this.checkAckStatus(name.ack)}</div>
        }


    }





    render() {
        return (
            <body className="font-montserrat">
                <div id="main_content">
                    <div className="page">

                        <div className="">

                            <div className="row clearfix">
                                <div className="col-xl-12 col-lg-12">
                                    <div className="card">
                                        <div className="card-header">
                                            <ul class="nav nav-tabs page-header-tab">
                                                <li class="nav-item"><Link to="/ViewAlarms" class="nav-link active show" data-toggle="tab">View Alarms</Link></li>

                                                <li class="nav-item"> <Link to="/HistoricAlarms" class="nav-link inactive show" data-toggle="tab"> Historic Alarms</Link></li>

                                            </ul>
                                            {/* <div className="card-options">
                                     <button className="btn btn-sm btn-outline-secondary mr-1" id="one_month">1M</button>
                                    <button className="btn btn-sm btn-outline-secondary mr-1" id="six_months">6M</button>
                                    <button className="btn btn-sm btn-outline-secondary mr-1" id="one_year" class="active">1Y</button>
                                    <button className="btn btn-sm btn-outline-secondary mr-1" id="ytd">YTD</button>
                                    <button className="btn btn-sm btn-outline-secondary" id="all">ALL</button>
                                </div> */}
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* <div class="section-body">
                    <div class="container-fluid">
                        <div class="row clearfix">
                            <div class="col-md-12">
                                <div class="tab-content">
                                    <div class="tab-pane active show" id="Company_Settings">
                                        <div class="card">
                                        <div class="card-header">
                                                <h3 class="card-title">Search Alarms</h3>
                                                <div class="card-options">
                                                    <a href="#" class="card-options-collapse" data-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a>
                                                    <a href="#" class="card-options-fullscreen" data-toggle="card-fullscreen"><i class="fe fe-maximize"></i></a>
                                                    <a href="#" class="card-options-remove" data-toggle="card-remove"><i class="fe fe-x"></i></a>
                                                </div>
                                            </div>
                                            <div class="card-body">
                                                <form>
                                                    <div class="row">
                                                    <div className="col-md-3 col-sm-12" style={{marginLeft:"30px"}}>  
                                                Start Date:    <DatePicker className="form-control"    
                                                    selected={this.state.startdate} placeholderText="Start Date" showPopperArrow={false}    
                                                    onChange={this.Changedate}
                                                    />    
                                                    </div>  
                                                    <div className="col-md-3 col-sm-12" style={{marginLeft:"-20px"}}>  
                                                End Date:    <DatePicker className="form-control"    
                                                    selected={this.state.enddate} placeholderText="End Date" showPopperArrow={false}    
                                                    onChange={this.enddate}    
                                                    />    
                                                    </div>  
                                                        <div class="col-md-3 col-sm-12" >
                                                            <div class="form-group" style={{width:"50%", marginTop:"10px" }}>
                                                        
                                                            Device Name:  <input className="form-control" style={{marginLeft:"100px", marginTop:"-25px"}} placeholder="Device Name" type="text" value=""/>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3 col-sm-12">
                                                            <div class="form-group" style={{width:"50%", marginLeft:"1150px", marginTop:"-50px"}}>
                                                             
                                                            Tag Name: <input className="form-control"  style={{marginLeft:"100px", marginTop:"-25px"}} placeholder="Tag Name" type="text" value=""/>
                                                            </div>
                                                        </div>
                                                        </div>
                                                        <div className="col-sm-3 col-sm-12">  
                                                        <button type="submit" className="btn btn-success" style={{marginLeft:"700px"}}>Search</button>  
                                                        </div>  
                                                    
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> */}
                       
                            <div class="row">
                                <div className="col-md-3 col-sm-6" >

                                    <input style={{ marginLeft: "1340px" }}
                                        
                                        size="large"
                                        name="searchInput"
                                        value={this.state.searchInput || ""}
                                        onChange={this.handleChange}
                                        placeholder="Search"
                                    />
                                    

                                </div>
                            </div>
                           

                        <div className="">

                            <div className="tab-content">
                                <div className="tab-pane fade show active" id="list" role="tabpanel">
                                    <div className="row clearfix">
                                        <div className="col-lg-12">
                                            <div className="table-responsive" id="users">
                                                <table className="table  table-vcenter  table_custom border-style list">
                                                    <table className="table ">
                                                        <thead style={{ textAlign: "left", backgroundColor: "#252d42" }}>
                                                            <tr>
                                                                <th style={{ fontSize: "20px", color: "#E5E5E5", fontWeight: 'bold' }}>Date</th>
                                                                <th style={{ fontSize: "20px", color: "#E5E5E5", fontWeight: 'bold' }}>Time</th>
                                                                <th style={{ fontSize: "20px", color: "#E5E5E5", fontWeight: 'bold' }}>Device Name</th>
                                                                <th style={{ fontSize: "20px", color: "#E5E5E5", fontWeight: 'bold' }}>Tag Name</th>
                                                                <th style={{ fontSize: "20px", color: "#E5E5E5", fontWeight: 'bold' }}>Description</th>
                                                                <th style={{ fontSize: "20px", color: "#E5E5E5", fontWeight: 'bold' }}>Alm Value</th>
                                                                <th style={{ fontSize: "20px", color: "#E5E5E5", fontWeight: 'bold' }}>Ack Status</th>
                                                            </tr>
                                                        </thead>


                                                        <tbody  >
                                                            {this.state.name == null ? "" : this.state.name.map((name) => {


                                                                return <tr className="" style={{ textAlign: "left", backgroundColor: "#252d42", borderWidth: "1px", borderColor: "#FFFFFF", borderStyle: "solid" }}>

                                                                    {/* Date */}
                                                                    <td>{this.dateTD(name)}</td>

                                                                    {/* Time */}
                                                                    <td> {this.timeTD(name)}</td>

                                                                    {/* DeviceName */}
                                                                    <td  >{this.deviceNameTD(name)} </td>

                                                                    {/* TagName */}
                                                                    <td className="hidden-xs" >{this.tagNameTD(name)}</td>

                                                                    {/* Description */}
                                                                    <td className="hidden-xs" >{this.descriptionTD(name)}</td>

                                                                    {/* Alm Value */}
                                                                    <td className="hidden-xs" >{this.almValueTD(name)}</td>

                                                                    {/* AckStatus */}
                                                                    <td className="hidden-xs" >{this.ackStatusTD(name)}</td>

                                                                </tr>
                                                            })}

                                                        </tbody>
                                                    </table>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </body>
        )
    }
}