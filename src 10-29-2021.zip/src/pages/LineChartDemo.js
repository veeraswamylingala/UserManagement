import React, { useState, useEffect } from "react";
import HighchartsReact from "highcharts-react-official";
import Highcharts from "highcharts";
import {Link} from 'react-router-dom';

const LineChartDemo = props => {

    
  const [chartOptions, setChartOptions] = useState({
    series: [
      {
        data: (function() {
          // generate an array of random data
          var data = [],
            time = new Date().getTime(),
            i;

          for (i = -5; i <= 0; i += 1) {
            data.push({
              x: time + i * 1000,
              y: Math.random()
            });
          }
          return data;
        })(),
        color: "DarkGreen",
    //    fillColor: "rgba(105, 190, 40, 0.2)"
      },
      {
        data: (function() {
          // generate an array of random data
          var data1 = [],
            time = new Date().getTime(),
            i;

          for (i = -5; i <= 0; i += 1) {
            data1.push({
              x: time + i * 1000,
              y: Math.random()
            });
          }
          return data1;
        })(),
        color: "Black",
      //  fillColor: "rgba(105, 96, 40, 0.2)"
      },
      {
        data: (function() {
          // generate an array of random data
          var data2 = [],
            time = new Date().getTime(),
            i;

          for (i = -300; i <= 0; i += 1) {
            data2.push({
              x: time + i * 1000,
              y: Math.random()
           //  y: Math.setInterval()
            });
          }
          return data2;
        })(),
        color: "DarkRed",
        fillColor: "rgba(105, 96, 30, 0.2)"
      }
    ],
    chart: {
      type: props.shadow,
      zoomType: "x",
      backgroundColor: {
        linearGradient: {
          x1: 0,
          y1: 0,
          x2: 1,
          y2: 1
        },
        stops: [[0, "white"], [1, "white"]]
      },
      style: {
        fontFamily: "'Unica One', sans-serif"
      },
      tooltip: {
        backgroundColor: "rgba(0, 0, 0, 0.85)",
        style: {
          color: "#F0F0F0"
        }
      },
      //Style on window that pops up when hovering over plots
      plotOptions: {
        series: {
          dataLabels: {
            color: "#F0F0F3",
            style: {
              fontSize: "13px"
            }
          },
          marker: {
            lineColor: "#333"
          }
        },
        boxplot: {
          fillColor: "#505053"
        },
        candlestick: {
          lineColor: "white"
        },
        errorbar: {
          color: "white"
        }
      },
      credits: {
        style: {
          color: "#666"
        }
      },
      labels: {
        style: {
          color: "#707073"
        }
      },
      drilldown: {
        activeAxisLabelStyle: {
          color: "#F0F0F3"
        },
        activeDataLabelStyle: {
          color: "#F0F0F3"
        }
      },
      navigation: {
        buttonOptions: {
          symbolStroke: "#DDDDDD",
          theme: {
            fill: "#505053"
          }
        }
      },
      events: {
        load: function() {
          // set up the updating of the chart each second
          var series = this.series[0];
          var series1 = this.series[1];
          var series2 = this.series[2];
          setInterval(function() {
            
            var x = new Date().getTime(), // current time
              y = 5;
            series.addPoint([x, y+1], true, true);
            series1.addPoint([x, y+1], true, true);
            series2.addPoint([x, y+1], true, true);
          }, 1000);
          
        }
      }
    },
    title: {
      text: "",
      style: {
        color: "#E0E0E3",

        fontSize: "20px"
      }
    },
    legend: {
      backgroundColor: "rgba(0, 0, 0, 0.5)",
      itemStyle: {
        color: "#E0E0E3"
      },
      itemHoverStyle: {
        color: "#FFF"
      },
      itemHiddenStyle: {
        color: "#606063"
      },
      title: {
        style: {
          color: "#C0C0C0"
        }
      }
    },
    xAxis: {
      type: "datetime",
      gridLineColor: "#707073",
      gridLineWidth: "1px",
      lineColor: "#707073",
      minorGridLineColor: "#505053",
      tickColor: "#707073",
      tickPixelInterval: 250,
      labels: {
        /*formatter: function () {
          return Highcharts.dateFormat('%Y %a %d %b %H:%M:%S', timezoneoffset(this.value));
        },*/
        y: 20,
        x: 0,
        autoRotation: false,
        /*rotation: 45,*/
        padding: 0,
        style: {
          color: "Black"
        }
      }
    },
    yAxis: {
      text: "",
      gridLineColor: "#707073",
      labels: {
        format: "{value} ",
        style: {
          color: "Black"
        }
      },
      lineColor: "#707073",
      minorGridLineColor: "#505053",
      tickColor: "#707073",
      tickWidth: 1,
      title: {
        text: "",
        style: {
          color: "Black",
          fontSize: "16px"
        }
      }
    }
  });

  //--------------------------------Change on events functions--------------------------------------------------

  useEffect(() => {
    //Change between shadow under graph or not shadow
    if (props.shadow === "spline") {
      setChartOptions({
        ...chartOptions,
        chart: { type: "areaspline" }
      });
    } else {
      setChartOptions({
        ...chartOptions,
        chart: { type: "spline" }
      });
    }
  }, [props.shadow]);

  return (

    <body className="font-montserrat">
    
    <div id="main_content">
    
        <div className="page">
        <div class="section-body">
                <div class="container-fluid">
                    <div class="row clearfix">
                        <div class="col-lg-12">
                            <div class="d-lg-flex justify-content-between">
                                <ul class="nav nav-tabs page-header-tab">
                                    <li class="nav-item"><Link to="/AreaTrends" class="nav-link active show" data-toggle="tab" href="#Area_Charts">Trends</Link></li>
    
                                    <li class="nav-item"><Link to="/HistoricTrends" class="nav-link" data-toggle="tab" href="#Email_Settings">Historic Trends</Link></li>
                                    
                                    <li class="nav-item"><Link to="/TabularTrends" class="nav-link" data-toggle="tab" href="#Change_Password">Tabular Trends </Link></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    <div>
    </div>
 
    

      <button onClick={props.changeType}>{props.shadow}</button>
      <HighchartsReact
        highcharts={Highcharts}
        options={chartOptions}
        //allowChartUpdate={{ allowUpdate }}
      />
    </div>
    </div>
    </body>
  );
};

export default LineChartDemo;
