import { useState } from "react";
import axios from "axios";
import React from "react";
import { Button, Modal } from "react-bootstrap";
import ReactApexChart from "react-apexcharts";
import "reactjs-popup/dist/index.css";
import { SketchPicker } from 'react-color'
import { Link } from 'react-router-dom';
import { Time } from "highcharts";

var tempDataPoints = [{ name: "", data: [], color: "" }];

const ChartSpace = () => {
  var selectedGroupName = "";

  //UseState for spanTime
  const [stroke, setStroke] = React.useState('smooth');

  //UseState for spanTime
  const [spanTime, setSpanTime] = React.useState(300000);
  //UseState for SampleRate
  const [sampleRate, setSampleRate] = React.useState(850);
  //UseState for ToStoptheGraph
  const [isGraphStopped, stopGraph] = React.useState(false);

  //Data to be taken when Clicking Edit Button
  const [selectedTagData, SetSelectedTagData] = React.useState({
    tagName: "",
    axisIndex: 0,
    color: "",
    upperValue: "",
    lowerValue: "",
  });

  //Data to be taken when Clicking Edit Button
  const [tempselectedTagData, SetTempSelectedTagData] = React.useState({
    color: "",
    upperValue: "",
    lowerValue: "",
  });

  //State variable for stop/start validation----
  const [length, setLength] = useState(0);

  //Model UseStates
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);

  //DropDown Groups-----------------
  const [groupsSelectTagValues, setGroupsSelectTagValues] = React.useState([]);

  //isGroupSelected
  const [isGroupSelected, setIsGroupSelected] = React.useState(false);

  //SelectedGroup
  const [selectedGroup, setSelectedGroup] = React.useState("");

    //UseState for ChartSeries Data
    const [dataList, setDataList] = React.useState([{}]);


  //GroupTagsData---
  const [selectedGoupTagsData, setSelectedGoupTagsData] = React.useState([]);

  //Function 1 -- Show Model
  const handleShow = (value) => {
    //console.log(value);
    SetSelectedTagData(value);
    setShow(true);
  };

  //Function 2 when adding higherValue and Lowervalue and saving 
  const onSave = (value) => {

    SetTempSelectedTagData({
      color: "",
      upperValue: "",
      lowerValue: "",
    })
    //console.log("Clicked");
    //console.log(value);

    //console.log(chartOptions.yaxis.length);

    //Tochange the Color and upperValue and LowerValue in Options------ 
    setChartOptions({
      yaxis: chartOptions.yaxis.map((axis, i) => {
        if (value.axisIndex == i) {
          return {
            ...chartOptions.yaxis[i],
            axisBorder: {
              show: true,
              color: value.color,
            },
            labels: {
              show: true,
              style: {
                colors: value.color,
              },
            },
            max: parseInt(value.upperValue),
            min: parseInt(value.lowerValue),
          };
        } else {
          return {
            ...axis,
          };
        }
      }),
    });

    //To change the Selectedcolor in Datalist----
    setDataList(
      dataList.map((list, i) => {
        if (value.axisIndex == i) {
          return {
            ...list,
            color: value.color,
          };
        } else {
          return {
            ...list,
          };
        }
      })
    );


localStorage.setItem("graphDataList",JSON.stringify(dataList))
//localStorage.setItem("graphOptions",JSON.stringify(dataList))



    setShow(false);
  };

  //AppexCharts Options---
  const options = {
    chart: {
      //Display the toolbar / menu in the top right corner.
      toolbar: {
        show: true,
        tools: {
          download: false,
          selection: false,
          zoom: true,
          zoomin: true,
          zoomout: true,
          pan: true,
        },
        autoSelected: "pan",
        //zoom
        //pan
        //selection
      },
      zoom: {
        enabled: true,
        type: "xy",
        autoScaleXaxis: false,
        zoomedArea: {
          fill: {
            color: "#90CAF9",
            opacity: 0.4,
          },
          stroke: {
            color: "#0D47A1",
            opacity: 0.4,
            width: 1,
          },
        },
      },

      animations: {
        enabled: true,
        easing: "easein",
        dynamicAnimation: {
          speed: 1000,
        },
      },
    },
    dataLabels: {
      enabled: false,
    },
    markers: {
      size: 0.5,
      enabled: true,
      /// strokeColors:["black"]

    },
    stroke: {
      width: [2, 2],
      curve: ["smooth", "smooth"],
      //smooth,straight,stepline
    },
    title: {
      text: "Current Trends",
      align: "left",
      offsetX: 110,
    },
    grid: {
      row: {
        colors: ["#f3f3f3", "transparent"], // takes an array which will be repeated on columns
        opacity: 0.5,
      },
    },
    tooltip: {
      x: {
        format: "dd/MM/yyyy HH:mm:ss",
      },
    },
    xaxis: {
      type: "datetime",

      //Default TimeSpan 5 min 
      range: spanTime,

      labels: {
        datetimeUTC: false,
        // format: 'HH:mm',
      }
    },
    noData: {
      text: "Loading"
    },
    yaxis: {
      seriesName: "One",
      axisTicks: {
        show: true,
      },
      axisBorder: {
        show: true,
        color: "Black",
      },
      labels: {
        show: true,
        style: {
          colors: "Black",
        },
      },
      // title: {
      //   text: v,

      //   style: {
      //     color: lineColors[i],
      //   },
      // },
      min: parseInt(0),
      max: parseInt(100),
    }

  };


  //UseState for ChartOPtions Data
  const [chartOptions, setChartOptions] = React.useState(options);



  //UseEffect
  React.useEffect(() => {
    console.log(localStorage.getItem("selectedGroupName"));

    ///fetching Datalist from LocalStorage
    var localStorageDatalist = JSON.parse(localStorage.getItem("graphDataList"));
    console.log(localStorageDatalist?.length)
    console.log(localStorageDatalist)

    if(localStorageDatalist != null)
    {
     setDataList(localStorageDatalist)
    }
    
    if (!isGroupSelected) {
      getGroupNames();
    }

  }, []);



  //GetGroupNames Api Call------------------------------------------------------
  function getGroupNames() {
    //console.log("Calling Groups Names Api")
    axios.get('http://localhost/ScadaClient/api/GroupName?GroupName=').then(res => {

      var groupNamesData = res.data;
      //console.log(groupNamesData)
      //Making 0 Index CURTRENDTITLE Default group --- toFetch values when page is rendering
      //console.log("Default Group"+groupNamesData[0].CURTRENDTITLE)
      //console.log(groupNamesData[0].CURTRENDTITLE)
      console.log(localStorage.getItem("selectedGroupName"))

      if (localStorage.getItem("selectedGroupName") == null) {

        selectedGroupName = groupNamesData[0].CURTRENDTITLE;
        setSelectedGroup(groupNamesData[0].CURTRENDTITLE);

        localStorage.setItem("selectedGroupName", selectedGroupName)
      }
      else {

        var locaGroup = localStorage.getItem("selectedGroupName");
        console.log(locaGroup)
        selectedGroupName = locaGroup
        setSelectedGroup(locaGroup);
      }





      //Setting GroupSelectTagValues---to  get Groups in DropDown
      var dropDownData = [];
      groupNamesData.map((tag) => {
        dropDownData.push({ value: tag.CURTRENDTITLE, label: tag.CURTRENDTITLE })
      })
      setGroupsSelectTagValues(dropDownData);

      setIsGroupSelected(true);
      //Fetching 0th Group Tag Data after Setting  Default group
      fetchTagData();

    });
  }


  function fetchTagData() {
    var localGroup =  "";
    console.log("Fetching Group Tag Values ---")
    //console.log(selectedGroupName)
    //console.log(selectedGroup)
    //http://localhost/ScadaClient/api/GroupwithTrendsTimestamp?GroupName=DAS_GRP2
    if (selectedGroup != undefined) {
      var call = 'http://localhost/ScadaClient/api/GroupwithTrendsTimestamp?GroupName=' + selectedGroupName;

      //console.log(call)
      axios.get(call).then(res => {

        var tagData = [];

        tagData = res.data;
        //console.log("Actual List")
        //console.log(tagData)
        setSelectedGoupTagsData(tagData);
        //Condition

           localGroup =  localStorage.getItem("selectedGroupName");
        var localStorageDatalist = JSON.parse(localStorage.getItem("graphDataList"));
        //var localGraphOptions = JSON.parse(localStorage.getItem("graphOptions"));

        console.log(localGroup)
        console.log(selectedGroupName)
        console.log(localStorageDatalist)
        //console.log(localGraphOptions)
    
        var tempDataPoints = [];

        if(localStorageDatalist != null && selectedGroupName == localGroup )
        {
        
          tempDataPoints = localStorageDatalist;
        }else{
       
          //Add Dummy Data to DataList
        tagData.map((tag) => {
          tempDataPoints.push(
            {
              name: tag.POINTNAME,
              data: [],
              color: colorConvertion(tag.PENCOLOR)
            })
        })
      }
      //Setting Data List either LocalDataList or Empty/Dummy Datalist------
        setDataList(tempDataPoints);

        //Checking LocalGrpahOptions and its Group to Set Chart Options------
        // if(localGraphOptions != null && selectedGroupName == localGroup)
        // {
        //   console.log("If")
        //   setChartOptions(localGraphOptions);

        // }
        // else{
        //   console.log("else")

          //Creating YAxis Based on TagDtaa----------------------------
        var data = tagData.map((tag) => {
          return {
            seriesName: tag.POINTNAME,
            axisTicks: {
              show: true,
            },
            axisBorder: {
              show: true,
              color: colorConvertion(tag.PENCOLOR),
            },
            labels: {
              show: true,
              style: {
                colors: colorConvertion(tag.PENCOLOR),
              },
            },
            // title: {
            //   text: v,

            //   style: {
            //     color: lineColors[i],
            //   },
            // },
            min: parseInt(tag.LOWERVALUE),
            max: parseInt(tag.UPPERVALUE),
          }
        })

        //Stroke------
        var srokeWidth = [];
        var strokeCurve = [];

        //Markers-----
        var markerColors = [];
        //Setting Stroke for each Tag in tagsData-----
        tagData.map((tag) => {
          strokeCurve.push(stroke);
          //smooth,straight,stepline
          srokeWidth.push(2);
          markerColors.push(colorConvertion(tag.PENCOLOR));
        })

        //Assiging Stroke,markers,Yaxis to ChartOptions --------------------
        setChartOptions({
          ...chartOptions,
          stroke: {
            width: srokeWidth,
            curve: strokeCurve,
            //smooth,straight,stepline
          },
          markers: {
            size: 0,
            strokeColors: markerColors,

          },
          yaxis: data
        });
      
      })
    }
  }


  function colorConvertion(color) {
    // //console.log(color)
    //Converting colors to hexRGB COlor
    const [, alpha, ...colorArray] = ('00000000' + color.toString(16)).slice(-8).match(/([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})/i)
    var hexARGBColor = `#${colorArray.join('')}${alpha}`
    return hexARGBColor;
  }


  //UseEffect
  React.useEffect(() => {

    //AddDataRandomly  Function------------------
    const addDataRandomly = (data, Yvalue) => {
      //  //console.log(Yvalue)
      var value = Yvalue.toFixed(1);
      // //console.log(value)


      const min = 1;
      const max = 100;
      const rand = min + Math.random() * (max - min);

      return [
        ...data,
        {
          x: new Date().toLocaleString(),

          // this will generate Random Number-
          y: parseInt(rand,10)
          //y: value
        },
      ];
    };

    //Timer for Every Selected Time Interval
    const interval = setInterval(() => {
      // //console.log(selectedGroupName)
      ////console.log(selectedGroup)
      //  //console.log("DataList Length" +  dataList[0].data.length)
      //http://localhost/ScadaClient/api/GroupwithTrendsTimestamp?GroupName=DAS_GRP2
      //https://demo3412.herokuapp.com/tag
      axios.get(`http://localhost/ScadaClient/api/GroupwithTrendsTimestamp?GroupName=` + selectedGroup).
        then((res) => {
          ////console.log(res.data);
          var tagData = res.data;
          setSelectedGoupTagsData(tagData)
          //  //console.log(tagData)
          //isGraphStopped is  equal to false
          if (!isGraphStopped) {
            ////console.log("Graph is Active");
            //Validation to plot points to graph even the chart is stopped
            if (length != 0) {
              setDataList(tempDataPoints);
              setLength(0);
              //console.log("Length is", length);
            } else {
              setDataList(
                dataList.map((val, i) => {

                  return {
                    name: val.name,
                    data: addDataRandomly(val.data, tagData[i]?.fvalue),
                    color: val.color,
                  };
                })
              );
              console.log(dataList[0].data.length)
              localStorage.setItem("graphDataList",JSON.stringify(dataList))
            }
          } else {
            //console.log("Graph Stopped");
            //console.log(length)
            //Validation to plot points to graph even the chart is stopped
            //in first step we are assigning complete dataList to TempList
            if (length == 0) {
              //console.log(dataList);
              tempDataPoints = dataList;
              setLength(dataList.length);
            }
            //Here doing the same process with tempList and storing into tempDataList
            //console.log(tempDataPoints[0]['data'].length);
            tempDataPoints = tempDataPoints.map((val, i) => {
              //   //console.log(addDataRandomly(val.data))
              return {
                name: val.name,
                data: addDataRandomly(val.data, tagData[i].fvalue),
                color: val.color,
              };
            });
          }
        })
    }, sampleRate);

    return () => clearInterval(interval);
  });


  //Hidden Clicked------------

  function hiddenOnClick(e) {
    console.log("hidden Selected");

    console.log(e);
    
    chartOptions.hideSeries("DTms_0010")
    console.log(e.target.value)


    // this.myChart.data.datasets[e].hidden  = !this.myChart.data.datasets[e].hidden;

    //setSelectedGoupTagsData();
    // this.myChart.update();
    // this.setState({})

  }

  //Select Group OnSelection Group
  const groupSelected = (e) => {
    //console.log("DropdoWNclicked");
    var value = e.target.value;
      console.log(value)
    setSelectedGroup(value);
    selectedGroupName = value;
    localStorage.setItem("selectedGroupName", value)
      localStorage.setItem("graphDataList",null);
      //localStorage.setItem("graphOptions",null);
    fetchTagData();
  

  };

  //Select Stroke OnSelection 
  const strokeSelected = (e) => {
    //console.log(" Stroke DropdoWNclicked");
    var value = e.target.value;
    //console.log(value)
    setStroke(value);

    var srokeWidth = [];
    var strokeCurve = [];

    dataList.map((tag) => {
      strokeCurve.push(value);
      //smooth,straight,stepline
      srokeWidth.push(2);
    })

    //T.EVERY IS NOT fUNCTION--
    setChartOptions({
      ...chartOptions,
      stroke: {
        width: srokeWidth,
        curve: strokeCurve,
        //smooth,straight,stepline
      },

    });


    // selectedGroupName = value;
    // fetchTagData();

  };

  // Select Marker Values
  const MarkerSelected = (e) => {

    var value = e.target.value;
    var markerColors = []
    //console.log(value)

    //T.EVERY IS NOT fUNCTION--
    setChartOptions({
      ...chartOptions,
      markers: {
        size: value,
      },
    });

  }


  return (
    <div >
      <div class="section-body">
        <div class="container-fluid">
          <div class="row clearfix">
            <div class="col-lg-12">
              <div class="d-lg-flex justify-content-between">
                <ul class="nav nav-tabs page-header-tab">
                  <li class="nav-item"><Link to="/AreaTrends" class="nav-link active show " data-toggle="tab" href="">Trends</Link></li>

                  <li class="nav-item"><Link to="/HistTrends" class="nav-link " data-toggle="tab" href="">Historic Trends</Link></li>

                  <li class="nav-item"><Link to="/TabularTrends" class="nav-link" data-toggle="tab" href="#Change_Password">Tabular Trends </Link></li>
                  <li class="nav-item"><a href='/AdminDashboard'  >AdminDashboard</a></li>


                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="container-fluid" >
        <div class="row">
          <div class="col-md-12 col-xs-7 ">
            <br></br>
            <div class="card text-black bg-light mb-3">
              {/* <div class="card-header">Graph</div> */}
              <div class="card-body">
                {/* Chart---------------------------------------------- */}
                <div class="row">
                  <div class="col-md-12 col-xs-7 ">
                    <div id="chart">
                      <div id="chart-timeline">
                        <ReactApexChart
                          height={window.screen.height / 2}
                          type="line"
                          options={chartOptions}
                          series={dataList}
                        />
                      </div>

                      <div></div>
                    </div>
                  </div>
                </div>
                <div class="row">

                  {/* Select Group DropDown-------------------------------------- */}
                  <div class="col-md-2" style={{ textAlign: "left" }}>

                    <div class="row" >
                      <div class="col-md-6" style={{ textAlign: "right" }}>
                        <label>Select Group: </label>
                      </div>
                      <div class="col-md-6" style={{ textAlign: "right" }}>
                        <select className="custom-select" value={selectedGroup}  onChange={groupSelected} >

                          {groupsSelectTagValues.map(name => (
                            < option value={name.value}>
                              {name.value}
                            </option>
                          ))}

                        </select>
                      </div>
                    </div>
                  </div>
                  {/* Select Stroke DropDown-------------------------------------- */}
                  <div class="col-md-2" style={{ textAlign: "right" }}>

                    <div class="row" >
                      <div class="col-md-6" style={{ textAlign: "right" }}>
                        <label>Select Stroke: </label>
                      </div>
                      <div class="col-md-6" style={{ textAlign: "right" }}>
                        <select className="custom-select" onChange={strokeSelected} >

                          <option value={'smooth'}> {'Smooth'} </option>
                          <option value={'straight'}> {'Straight'} </option>
                          <option value={'stepline'}> {'Stepline'} </option>

                          {/* //smooth,straight,stepline */}
                        </select>
                      </div>
                    </div>
                  </div>
                  {/* // for marker value */}

                  <div class="col-md-2" style={{ textAlign: "right" }}>

                    <div class="row" >
                      <div class="col-md-6" style={{ textAlign: "right" }}>
                        <label>Markers Value: </label>
                      </div>
                      <div class="col-md-6" style={{ textAlign: "center" }}>
                        <select className="custom-select" onChange={MarkerSelected} >

                          <option value={'0'}> {'Plain'} </option>
                          <option value={'.9'}> {'Dots'} </option>


                          {/* //smooth,straight,stepline */}
                        </select>
                      </div>
                    </div>
                  </div>



                  {/* Start and Stop Button-------------------------------------- */}
                  <div class="col-md-2">
                    {/* //   <div style={{textAlign:"right"}}> */}
                    <label style={{ marginLeft: "40px" }}>start/stop: </label> &nbsp; &nbsp;
                    <button
                      style={{ backgroundColor: isGraphStopped ? 'red' : "green", color: "white" }}
                      id="all"
                      onClick={() => {
                        //console.log(chartOptions.xaxis)
                        stopGraph(!isGraphStopped);
                      }}
                    // className={this.state.selection === "all" ? "active" : ""}
                    >

                      {isGraphStopped ? "Start" : "Stop"}
                    </button>
                    {/* </div> */}
                  </div>

                  {/* Window Span-------------------------------------- */}
                  <div class="col-md-2.5" style={{ textAlign: "right" }}>
                    <div class="toolbar">
                      <label>Window Span: </label> &nbsp; &nbsp;
                      <button

                        style={{ backgroundColor: spanTime == "60000" ? "green" : "grey", color: "white" }}
                        id="one_month"
                        onClick={() => {
                          //setWindowSpan(60),
                          setChartOptions({
                            ...chartOptions,
                            xaxis: {
                              range: 60 * 1000,
                            },
                          });
                          setSpanTime(60000);
                        }}
                      // className={this.state.selection === "one_month" ? "active" : ""}
                      >   1M
                      </button>
                      &nbsp;
                      <button
                        style={{ backgroundColor: spanTime == "120000" ? "green" : "grey", color: "white" }}
                        id="six_months"
                        onClick={() => {
                          setChartOptions({
                            ...chartOptions,
                            xaxis: {
                              range: 120 * 1000,
                            },
                          });
                          setSpanTime(120000);
                        }}
                      // className={this.state.selection === "six_months" ? "active" : ""}
                      >
                        2M
                      </button>
                      &nbsp;
                      <button
                        style={{ backgroundColor: spanTime == "180000" ? "green" : "grey", color: "white" }}
                        id="one_year"
                        onClick={() => {

                          setChartOptions({
                            ...chartOptions,
                            xaxis: {
                              range: 180 * 1000,
                            },
                          });
                          setSpanTime(180000);
                        }

                        }
                      // className={this.state.selection === "one_year" ? "active" : ""}
                      >
                        3M
                      </button>
                      &nbsp;
                      <button
                        id="ytd"
                        style={{ backgroundColor: spanTime == "300000" ? "green" : "grey", color: "white" }}
                        onClick={() => {
                          setChartOptions({
                            ...chartOptions,
                            xaxis: {
                              range: 300 * 1000,
                            },
                          });
                          setSpanTime(300000);
                        }
                        }
                      // className={this.state.selection === "ytd" ? "active" : ""}
                      >
                        5M
                      </button>
                    </div>
                  </div>

                  {/* Sample Rate-------------------------------------- */}
                  <div class="col-md-2" style={{ textAlign: "right" }}>
                    <label>Sample Rate: </label> &nbsp; &nbsp;
                    <button
                      style={{ backgroundColor: sampleRate == "1000" ? "green" : "grey", color: "white" }}
                      id="one_month"
                      onClick={() => setSampleRate(1000)}
                    // className={this.state.selection === "one_month" ? "active" : ""}
                    >
                      1s
                    </button>{" "}
                    &nbsp;
                    <button
                      id="one_month"
                      onClick={() => setSampleRate(2000)}
                      style={{ backgroundColor: sampleRate == "2000" ? "green" : "grey", color: "white" }}
                    // className={this.state.selection === "one_month" ? "active" : ""}
                    >
                      2s
                    </button>{" "}
                    &nbsp;
                    <button
                      id="one_month"
                      style={{ backgroundColor: sampleRate == "3000" ? "green" : "grey", color: "white" }}
                      onClick={() => setSampleRate(3000)}
                    // className={this.state.selection === "one_month" ? "active" : ""}
                    >
                      3s
                    </button>{" "}
                    &nbsp;
                    <button
                      style={{ backgroundColor: sampleRate == "5000" ? "green" : "grey", color: "white" }}
                      id="one_month"
                      onClick={() => setSampleRate(5000)}
                    // className={this.state.selection === "one_month" ? "active" : ""}
                    >
                      5s
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* //Table ----------------------------------------------------------------------------------------------------------- */}
        <div class="row">
          <div class="col-md-8">

            <table class="table table-bordered" color="black" >
              <th scope="col" style={{ textAlign: "-webkit-center", fontWeight: "bold" }}>Enable/Disable</th>
              <th scope="col" style={{ fontWeight: "bold" }}>Name</th>
              <th scope="col" style={{ fontWeight: "bold" }}>HigherValue</th>
              <th scope="col" style={{ fontWeight: "bold" }}>LowerValue</th>
              <th scope="col" style={{ fontWeight: "bold" }}>FValue</th>
              <th scope="col" style={{ fontWeight: "bold" }}> LastUpdated</th>
              <th scope="col" style={{ fontWeight: "bold" }}>Edit</th>


              {
                dataList != undefined ? selectedGoupTagsData.map((tag, i) => {

                  var list = dataList[i];
                  // //console.log(chartOptions.yaxis[i]?.max)
                  // //console.log(chartOptions.yaxis[i]?.min)

                  return (
                    <tr>
                      <td style={{ textAlign: "-webkit-center" }} > <input type="checkbox" onChange={() => hiddenOnClick(i)} /> </td>
                      <td style={{ color: list?.color }}>{tag.POINTNAME}</td>
                      <td style={{ color: list?.color }}>
                        {chartOptions.yaxis[i]?.max}
                      </td>
                      <td style={{ color: list?.color }}>
                        {chartOptions.yaxis[i]?.min}
                      </td>
                      <td style={{ color: list?.color }}>
                        {tag.fvalue}
                      </td>
                      <td style={{ color: list?.color }}>
                        {/* {(tag.timestamp.split(".")[0]).split("T")[1]} */}
                        {tag.timeStampTime}
                        {/* {console.log( new Date(new Date(tag.timestamp).getTime()-900))} */}
                      </td>
                      <td>
                        <button
                          onClick={() =>
                            handleShow({
                              tagName: tag.POINTNAME,
                              axisIndex: i,
                              color: list?.color,
                              upperValue: chartOptions.yaxis[i]?.max,
                              lowerValue: chartOptions.yaxis[i]?.min,
                            })
                          }
                          style={{ background: list?.color }}
                          className="btn btn-secondary btn-sm"
                        >
                          Edit
                        </button>
                      </td>
                    </tr>
                  );
                }) : <div></div>}
            </table>
          </div>
        </div>

        <div>
          <Modal
            show={show}
            //   onHide={this.props.onHide}
            animation={false}
            fade={true}
            backdrop="false"
            style={{ marginLeft: "700px", marginTop: "200px" }}

            size="small"
            centered
          >
            <Modal.Header >
              <Modal.Title>
                {" "}
                {selectedTagData["axisIndex"] + 1}{". "}
                {selectedTagData["tagName"]}
              </Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <div class="form-group">
                UpperValue
                <input
                  type="text"
                  class="form-control"
                  placeholder={selectedTagData["upperValue"]}
                  onChange={(e) => {
                    //console.log(e.target.value)
                    SetTempSelectedTagData({
                      upperValue: e.target.value,
                      lowerValue: tempselectedTagData.lowerValue ? tempselectedTagData.lowerValue : selectedTagData["lowerValue"],
                      color: tempselectedTagData.color ? tempselectedTagData.color : selectedTagData["color"]
                    })
                  }}
                />
              </div>
              <div class="form-group">
                LowerValue
                <input
                  type="text"
                  class="form-control"
                  placeholder={selectedTagData["lowerValue"]}
                  onChange={(e) => {
                    //console.log(e.target.value)
                    SetTempSelectedTagData({
                      upperValue: tempselectedTagData.upperValue ? tempselectedTagData.upperValue : selectedTagData["upperValue"],
                      lowerValue: e.target.value,
                      color: tempselectedTagData.color ? tempselectedTagData.color : selectedTagData["color"]
                    })
                  }}
                />
              </div>
              <div class="row">
                <label for="inputEmail">Select Pen Color : </label> &nbsp; &nbsp;
                {/* <Button style={{background:this.state.color}} onClick={this.props.onHide}>
          
          </Button> */}
                {/* npm i @uiw/react-color-sketch */}
                {/* <Sketch
              style={{ marginLeft: 20 }}
              color={this.props.tagData["color"]}
              onChange={(color) => {
                this.setState({ color: color.hex });
              }}
            /> */}
                {/* npm i react-SketchPicker */}
                <SketchPicker style={{ background: selectedTagData["color"] }}
                  color={tempselectedTagData.color ? tempselectedTagData.color : selectedTagData["color"]}
                  onChange={(color) => {
                    //console.log(color.hex)
                    //console.log(tempselectedTagData)

                    SetTempSelectedTagData({
                      upperValue: tempselectedTagData.upperValue ? tempselectedTagData.upperValue : selectedTagData["upperValue"],
                      lowerValue: tempselectedTagData.lowerValue ? tempselectedTagData.lowerValue : selectedTagData["lowerValue"],
                      color: color.hex
                    })
                  }}
                />
              </div>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary"
                onClick={handleClose}>
                Close
              </Button>
              <Button variant="primary"
                onClick={() => onSave({
                  tagName: selectedTagData['tagName'],
                  axisIndex: selectedTagData['axisIndex'],
                  color: tempselectedTagData.color ? tempselectedTagData.color : selectedTagData["color"],
                  upperValue: tempselectedTagData.upperValue ? tempselectedTagData.upperValue : selectedTagData["upperValue"],
                  lowerValue: tempselectedTagData.lowerValue ? tempselectedTagData.lowerValue : selectedTagData["lowerValue"],
                })

                }
              >
                Save Changes
              </Button>
            </Modal.Footer>
          </Modal>

        </div>
      </div>
    </div>
  );
};

export default ChartSpace;
