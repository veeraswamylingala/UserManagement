import React, { Component } from 'react';
import { ChromePicker } from 'react-color'
import reactCSS from 'reactcss'
import { SketchPicker } from 'react-color'
import "./Modal.css"


class Modal extends React.Component {
  constructor(props) {
    super(props);
    this.handleSave = this.handleSave.bind(this);
    this.state = {
      UPPERVALUE: '',
      LOWERVALUE: '',
      displayColorPicker: false,
      requiredColor:"",
      color: {
        r: 241,
        g: 112,
        b: 19,
        a: 1,
      },
    }
   

  }

  androidTorgb = (color) => {
    const colorArray = []
    for (let i = 0; i < 4; i++) {
      colorArray.push(color % 256)
      color >>>= 8
    }
    const alpha = colorArray.pop() / 255
    var color = `${colorArray.reverse()},${alpha}`
    var temp = color.split(",")
    var rgbaColor = {
      r: temp[0],
      g: temp[1],
      b: temp[2],
      a: '1',
    }
    return rgbaColor;
  }


  componentWillReceiveProps(props) {


    console.log(props.COLOR)
      var temp = this.androidTorgb( props.COLOR)
      
     
      this.setState({
        color: temp
      },()=>{

      })
    

    
  }
  handleClick = () => {
    this.setState({ displayColorPicker: !this.state.displayColorPicker })
  };

  handleClose = () => {
    this.setState({ displayColorPicker: false })
  };

  titleHandler(e) {
    this.setState({ UPPERVALUE: e.target.value });
  }

  msgHandler(e) {
    this.setState({ LOWERVALUE: e.target.value });
  }

  handleSave() {
    const item = this.state;
    this.setState({ UPPERVALUE: "" });
    this.setState({ LOWERVALUE: "" });
    this.setState({ color: "" });
    this.props.saveModalDetails(item)
  }
  handleClick = () => {
    this.setState({ displayColorPicker: !this.state.displayColorPicker })
  };

  handleClose = () => {
    this.setState({ displayColorPicker: false })
  };


  handleChange = (color) => {
    console.log(color.rgb)
    this.setState({ color: color.rgb })
  };


  render() {
    console.log(this.props.COLOR)
    const styles = reactCSS({
      'default': {
        color: {
          width: '36px',
          height: '14px',
          borderRadius: '2px',
          background: `rgba(${this.state.color.r}, ${this.state.color.g}, ${this.state.color.b}, ${this.state.color.a})`,
        },
        swatch: {
          padding: '5px',
          background: '#fff',
          borderRadius: '1px',
          boxShadow: '0 0 0 1px rgba(0,0,0,.1)',
          display: 'inline-block',
          cursor: 'pointer',
        },
        popover: {
          position: 'absolute',
          zIndex: '2',
        },
        cover: {
          position: 'fixed',
          top: '0px',
          right: '0px',
          bottom: '0px',
          left: '0px',
        },
      },
    });
    return (
      <div className="modal fade" id="myModal" data-backdrop="false" style={{ marginLeft: "900px", width: "500px" }} >
        <div className="modal-dialog modal-sm" >
          <div className="modal-content">
            <div className="modal-header" >
              <p>Settings</p>
              {/* <h5 className="modal-title" id="exampleModalLabel">Edit Jewel</h5> */}
              <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div className="modal-body">
              <p>{this.props.POINTNAME}</p>
              <p><span className="modal-lable">High Limit:</span><input value={this.state.UPPERVALUE} placeholder={this.props.UPPERVALUE} onChange={(e) => this.titleHandler(e)} /></p>
              <p><span className="modal-lable">Low Limit:</span><input value={this.state.LOWERVALUE} placeholder={this.props.LOWERVALUE} onChange={(e) => this.msgHandler(e)} /></p>
              <p>Please choose the color</p>
              <div style={styles.swatch} onClick={this.handleClick}>
                <div style={styles.color} />
              </div>
              {this.state.displayColorPicker ? <div style={styles.popover}>
                <div style={styles.cover} onClick={this.handleClose} />
                <SketchPicker color={this.state.color} onChange={this.handleChange} />
              </div> : null}

            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="button" className="btn btn-primary" data-dismiss="modal" onClick={() => { this.handleSave() }}>Update</button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Modal;