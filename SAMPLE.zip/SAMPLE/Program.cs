﻿using System;
using System.Runtime.InteropServices;
using System.Xml.Serialization;

namespace Implement
{
    public struct statusrec
    {
        #region structure declaration
        /*
        public static int dbirlow=1;
        public static int dblolo =1;
        public static int dblow = 1;
        public static int dbrocl = 1;
        public static int dbroch = 1;
        public static int dbhigh = 1;
        public static int dbhihi = 1;
        public static int dbirhigh = 1;
        public static int dbmsl = 1;
        public static int dbcnp = 1;
        public static int dbfailed = 1;
        public static int dbunack = 1;
        public static int dbbusied = 1;
        public static int dbalarminhibit = 1;
        public static int dbalarm = 1;
        public static int dbchattering1 = 1;
        public static int dbchattering2 = 1;
        public static int existing = 1;
        public static int dbold = 1;
        public static int dbontest = 1;
        public static int dbcommandedop = 1;
        
         
         
           public statusrec(int dbirlow, int dblolo, int dblow, int dbrocl, int dbroch, int dbhigh, int dbhihi, int dbirhigh,
            int dbmsl, int dbcnp, int dbfailed, int dbunack, int dbbusied, int dbalarminhibit, int dbalarm, int dbchattering1, int dbchattering2, int existing,
            int dbold, int dbontest, int dbcommandedop)
        {
              this.dbirlow = dbirlow;
            this.dblolo = dblolo;
            this.dblow = dblow;
            this.dbrocl = dbrocl;
            this.dbroch = dbroch;
            this.dbhigh = dbhigh;
            this.dbhihi = dbhihi;
            this.dbirhigh = dbirhigh;
            this.dbmsl = dbmsl;
            this.dbcnp = dbcnp;
            this.dbfailed = dbfailed;
            this.dbunack = dbunack;
            this.dbbusied = dbbusied;
            this.dbalarminhibit = dbalarminhibit;
            this.dbalarm = dbalarm;
            this.dbchattering1 = dbchattering1;
            this.dbchattering2 = dbchattering2;
            this.existing = existing;
            this.dbold = dbold;
            this.dbontest = dbontest;
            this.dbcommandedop = dbcommandedop;
        }
        
         */
        #endregion
        #region structure declaration - setter methods
        public static UInt32 dbirlow = 1;// { get;  set; }
        public static UInt32 dblolo = 1;// { get;  set; }
        public static UInt32 dblow = 1;//{ get;  set; }
        public static UInt32 dbrocl = 1;//{ get;  set; }
        public static UInt32 dbroch = 1;//{ get;  set; }
        public static UInt32 dbhigh = 1;//{ get;  set; }
        public static UInt32 dbhihi = 1;//{ get;  set; }
        public static UInt32 dbirhigh = 1;//{ get;  set; }
        public static UInt32 dbmsl = 1;// { get;  set; }
        public static UInt32 dbcnp = 1;//{ get;  set; }
        public static UInt32 dbfailed = 1;//{ get;  set; }
        public static UInt32 dbunack = 1;//{ get;  set; }
        public static UInt32 dbbusied = 1;//{ get;  set; }
        public static UInt32 dbalarminhibit = 1;//{ get; private set; }
        public static UInt32 dbalarm = 1;//{ get;  set; }
        public static UInt32 dbchattering1 = 1;//{ get;  set; }
        public static UInt32 dbchattering2 = 1;//{ get;  set; }
        public static UInt32 existing = 1;// { get;  set; }
        public static UInt32 dbold = 1;//{ get;  set; }
        public static UInt32 dbontest = 1;//{ get;  set; }
        public static UInt32 dbcommandedop = 1;
        #endregion
        #region constructor

        public statusrec(UInt32 dbirlow, UInt32 dblolo, UInt32 dblow, UInt32 dbrocl, UInt32 dbroch, UInt32 dbhigh, UInt32 dbhihi, UInt32 dbirhigh,
            UInt32 dbmsl, UInt32 dbcnp, UInt32 dbfailed, UInt32 dbunack, UInt32 dbbusied, UInt32 dbalarminhibit, UInt32 dbalarm, UInt32 dbchattering1, UInt32 dbchattering2, UInt32 existing,
            UInt32 dbold, UInt32 dbontest, UInt32 dbcommandedop)
        {
            dbirlow = dbirlow;
            dblolo = dblolo;
            dblow = dblow;
            dbrocl = dbrocl;
            dbroch = dbroch;
            dbhigh = dbhigh;
            dbhihi = dbhihi;
            dbirhigh = dbirhigh;
            dbmsl = dbmsl;
            dbcnp = dbcnp;
            dbfailed = dbfailed;
            dbunack = dbunack;
            dbbusied = dbbusied;
            dbalarminhibit = dbalarminhibit;
            dbalarm = dbalarm;
            dbchattering1 = dbchattering1;
            dbchattering2 = dbchattering2;
            existing = existing;
            dbold = dbold;
            dbontest = dbontest;
            dbcommandedop = dbcommandedop;
        }

        #endregion
    }

    public struct dbcv
    {
        // public float fvalue;
        // public int ivalue;
        static statusrec srec;

        //public static float fvalue = 1;//{ get; set; }
        //public static int ivalue = 1;//{ get; set; }
        public dbcv(float fvalue, int ivalue, out statusrec statusrec)
        {
            //fvalue = fvalue; ivalue = ivalue;
            //fvalue = 1;
            //ivalue = 1;
            //statusrec st = new statusrec();
            statusrec statusrec1 = new statusrec(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);
        }
    }
    //STATUSREC







    public class Program
    {

        public struct statusrec
        {
            uint dbirlow;
            uint dblolo;
            uint dblow;
            uint dbrocl;
            uint dbroch;
            uint dbhigh;
            uint dbhihi;
            uint dbirhigh;
            uint dbmsl;
            uint dbcnp;
            uint dbfailed;
            uint dbunack;
            uint dbopentered;
            uint dbbusied;
            uint dbalarminhibit;
            uint dbalarm;
            uint dbchattering1;
            uint dbchattering2;
            uint existing;
            uint dbold;
            uint dbontest;
            uint dbcommandedop;
        };

        public struct dbcv
        {
            float fvalue;
            int ivalue;
            statusrec srec;

        };
        /*
        // DBCV;
        statusrec statusrec11 = new statusrec(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);
        //dbcv dbcv = new dbcv(1, 1, ref statusrec11);
        //dbcv dbcv = new dbcv();
        dbcv dbcv;
        public Program(dbcv dbcv)
        {
            this.dbcv = dbcv;
        }

        dbcv cvv1;
        */
        public Program() { }

        [DllImport("dbserver.dll", EntryPoint = "DbGetSCADACurValue", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
        public static extern int DbGetSCADACurValue(UInt32 tpointId, out dbcv dbcv, out UInt32 time, out UInt32 pointType, UInt32 x);  //[MarshalAs(UnmanagedType.LPStruct)] 
        [DllImport("dbserver.dll", EntryPoint = "DbGetSCADACurValue", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
        public static extern int DbGetSCADACurValueVC(UInt32 tpointId, int ival, float fval);  //[MarshalAs(UnmanagedType.LPStruct)] 

        [DllImport("dbserver.dll", EntryPoint = "DbClientVC", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
        public static extern IntPtr DbClientVC();



        [DllImport("dbserver.dll", EntryPoint = "DbClientWebServer", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
        public static extern int DbClientWebServer();


        [DllImport("dbserver.dll")]

        public static extern int howareyou();
        [DllImport("dbserver.dll")]

        public static extern long GetPDBSize();
        [DllImport("dbserver.dll", EntryPoint = "GetPDBSize", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]

        public static extern int hello(int a);


        [DllImport("dbserver.dll", EntryPoint = "GetServerName", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
        public static extern string GetServerName();  //[MarshalAs(UnmanagedType.LPStruct)] 

        [DllImport("scriptingdll.dll", EntryPoint = "hallo1", ExactSpelling = false, CallingConvention = CallingConvention.Cdecl)]
        public static extern int hallo1();  //[MarshalAs(UnmanagedType.LPStruct)] 




        public static void Main()
        {

            //UInt32 time;

            //time= 1;

            uint pointType;
            int yy = 5;
            statusrec statusrec1 = new statusrec(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);
            dbcv cv = new dbcv(1, 1, out statusrec1);
            dbcv dvv = new dbcv();
            //, pointType;
            UInt32 tpointId;
            tpointId = 1;

            UInt32 time1 = 1;
            uint time;
            int ival = -1;
            float fval = -1;
             

            /*Console.WriteLine("output from dbserver dll of method howareyou: ");
            Console.WriteLine(howareyou());
            Console.WriteLine("output from dbserver dll of method hello: "); */
            //Console.WriteLine(hello(yy));
            //var dd =hallo1();
            //Console.WriteLine(dd);
            //var dd = DbClientWebServer();
            //if (dd < 0)
            //{
            //    Console.WriteLine("SCADA mappling error");
            //}
            //else
            {
                var aa = DbGetSCADACurValue(1, out cv, out time, out pointType, 8000);
            }
            //Console.WriteLine(a);
            //var ptr = GetPDBSize();
            // var ptrDbClient = DbGetSCADACurValue();


            // int aa;

            //aa = DbGetSCADACurValueVC(tpointId, ival, fval);
            //Console.WriteLine(ptrDbClient);
            //Console.WriteLine(ptrDbClient);
            //Console.WriteLine(DbGetSCADACurValue(tpointId,ref cv, out &time, out &pointType, 3000)); 
        }

    }
}
