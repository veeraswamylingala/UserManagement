module.exports = app => {
    const video_stream = require("../controllers/video_stream.controller");
  
    var router = require("express").Router();
  
    // Create a new video_stream
   router.post("/", video_stream.create);
  
    // Retrieve all video_stream
    router.get("/", video_stream.findAll);
  
    //Update Particual fileds
     router.put("/updateparticularfields/:Stream_Id", video_stream.updateparticularfields);
  
    // Retrieve a single video_streams with id
    router.get("/:Stream_Id", video_stream.findOne);
  
    // Update a Video_Stream with id
    router.put("/:Stream_Id", video_stream.update);
  
    // Delete a Video_Stream with id
    router.delete("/:Stream_Id", video_stream.delete);
  
    // Delete all video_stream
    router.delete("/", video_stream.deleteAll);
  
    app.use('/api/video_stream', router);
  };