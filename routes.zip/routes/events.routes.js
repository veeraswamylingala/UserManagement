module.exports = app => {

  
    const events = require("../controllers/events.controller.js");
  
    var router = require("express").Router();
  
    // Create a new Event
    router.post("/", events.create);
  
    // Retrieve all Event
    router.get("/", events.findAll);
  
    // // Retrieve all published users
    // router.get("/published", users.findAllPublished);
  
    // Retrieve a single Events with id
    router.get("/:Event_Id", events.findOne);
  
    // Update a Event with id
    router.put("/:Event_Id", events.update);
  
    // Delete a Event with id
    router.delete("/:Event_Id", events.delete);
  
    // Delete all events
    router.delete("/", events.deleteAll);
  
    app.use('/api/events', router);
  };