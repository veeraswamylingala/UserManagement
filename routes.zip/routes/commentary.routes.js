

module.exports = app => {

  
    const commentary = require("../controllers/commentary.controller.js");
  
    var router = require("express").Router();
  
    // Create a new commentry
    router.post("/", commentary.create);

  
    // Retrieve all commentry

    router.get("/",commentary.findAll);
  
    // // Retrieve all published users
    // router.get("/published", users.findAllPublished);
  
    // Retrieve a single commentrys with id
    router.get("/:commentry_id", commentary.findOne);
  
    // Update a commentry with id
    router.put("/:commentry_id", commentary.update);
  
    // Delete a commentry with id
    router.delete("/:commentry_id", commentary.delete);
  
    // Delete all commentrys
    router.delete("/", commentary.deleteAll);
  
    app.use('/api/commentary', router);
  };