module.exports = app => {

  
    const notifications = require("../controllers/notifications.controller");
  
    var router = require("express").Router();
  
    // Create a new notifications
    router.post("/", notifications.create);
  
    // Retrieve all notifications
    router.get("/", notifications.findAll);
  
    // // Retrieve all published users
    // router.get("/published", users.findAllPublished);
  
    // Retrieve a single notifications with id
    router.get("/:received_by", notifications.findOne);
  
    // Update a notifications with id
    router.put("/:Notification_Id", notifications.update);
  
    // Delete a notifications with id
    router.delete("/:Notification_Id", notifications.delete);
  
    // Delete all notifications
    router.delete("/", notifications.deleteAll);
  
    app.use('/api/notifications', router);
  };