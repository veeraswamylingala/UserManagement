module.exports = app => {

  
    const response_type = require("../controllers/response_type.controller");
  
    var router = require("express").Router();
  
    // Create a new response_type
    router.post("/", response_type.create);
  
    // Retrieve all response_type
    router.get("/", response_type.findAll);
  
    // // Retrieve all published users
    // router.get("/published", users.findAllPublished);
  
    // Retrieve a single response_type with id
    router.get("/:id", response_type.findOne);
  
    // Update a response_type with id
    router.put("/:id", response_type.update);
  
    // Delete a response_type with id
    router.delete("/:id", response_type.delete);
  
    // Delete all response_type
    router.delete("/", response_type.deleteAll);
  
    app.use('/api/response_type', router);
  };