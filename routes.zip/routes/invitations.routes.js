

module.exports = app => {

  
    const invitations = require("../controllers/invitations.controller");
  
    var router = require("express").Router();
  
    // Create a new Invitationsy
    router.post("/", invitations.create);

  
    // Retrieve all Invitationsy

    router.get("/",invitations.findAll);
  
    // // Retrieve all published users
    // router.get("/published", users.findAllPublished);
  
    // Retrieve a single Invitations with id
   
    router.get("/:invitation_id",invitations.findOne);
  
    // Update a Invitationsy with id
   

   router.put("/:invitation_id",invitations.update);
  
    // Delete a Invitationsy with id
    router.delete("/:invitation_id",invitations.delete);
    
  
    // Delete all Invitations
    router.delete("/", invitations.deleteAll);
  
    app.use('/api/invitations', router);
  };