module.exports = app => {

  
    const spotlights = require("../controllers/spotlights.controller");
  
    var router = require("express").Router();
  
    // Create a new spotlights
    router.post("/",spotlights.create);
  
    // Retrieve all spotlights
    router.get("/",spotlights.findAll);
  
    
    router.get("/:Id", spotlights.findOne);
    
  
    // Update a spotlights with id
   
    router.put("/:Id", spotlights.update);
  
    // Delete a spotlights with id
    router.delete("/:Id", spotlights.delete);
  
    // Delete all spotlightss
    router.delete("/", spotlights.deleteAll);
  
    app.use('/api/spotlights', router);
  };