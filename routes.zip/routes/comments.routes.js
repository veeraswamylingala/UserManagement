const { route } = require("express/lib/application");

module.exports = app => {

  
    const comments = require("../controllers/comments.controller");
  
    var router = require("express").Router();
  
    // Create a new comments
    router.post("/", comments.create);
  
    // Retrieve all comments
    router.get("/", comments.findAll);
  
    // // Retrieve all published users
    // router.get("/published", users.findAllPublished);
  
    // Retrieve a single commentss with id
    router.get("/:response_category_id/:reference_id",comments.findOne)
    
    // Update a comments with id
    router.put("/:Comment_Id", comments.update);
  
    // Delete a comments with id
    router.delete("/:user_id ",comments.delete)
   
  
    // Delete all commentss
    router.delete("/", comments.deleteAll);
  
    app.use('/api/comments', router);
  };