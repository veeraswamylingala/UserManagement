

module.exports = app => {

  
    const favourites = require("../controllers/favourites.controller");
  
    var router = require("express").Router();
  
    // Create a new commentry
    
    router.post("/",favourites.create);

  
    // Retrieve all commentry

    router.get("/",favourites.findAll);
  
    // // Retrieve all published users
    // router.get("/published", users.findAllPublished);
  

    router.get("/:response_category_id/:user_id",favourites.findOne);
   
    
  
    // Update a commentry with id
    router.put("/:Id",favourites.update);
    
  
    // Delete a commentry with id
    router.delete("/:Id",favourites.delete);
    
  
    // Delete all commentrys
    router.delete("/", favourites.deleteAll);
  
    app.use('/api/favourite', router);
  };