module.exports = app => {

    const groups = require("../controllers/groups.controller.js");
  
    var router = require("express").Router();
  
    // Create a new group
    router.post("/", groups.create);
  
    // Retrieve all group
    router.get("/", groups.findAll);
  
    // // Retrieve all published users
    router.get("/findAllwithUserID/:User_Id", groups.findAllwithUserID);
  
    // Retrieve a single groups with id
    router.get("/findAllwithGroupID/:Group_Id", groups.findOne);
  
    // Update a group with id
    router.put("/:Group_Id", groups.update);
  
    // Delete a group with id
    router.delete("/:Group_Id", groups.delete);
  
    // Delete all groups
    router.delete("/", groups.deleteAll);
  
    app.use('/api/groups', router);
  };