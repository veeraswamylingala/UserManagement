module.exports = app => {

  
    const highlights = require("../controllers/highlights.controller");
  
    var router = require("express").Router();
  
    // Create a new highlights
    router.post("/", highlights.create);
  
    // Retrieve all highlights
    router.get("/", highlights.findAll);
  
    // // Retrieve all published users
    // router.get("/published", users.findAllPublished);
  
    // Retrieve a single highlightss with id
    router.get("/:id", highlights.findOne);

    // Retrieve a single highlightss with Userid
    router.get("/Usersid/:User_Id", highlights.findallwithUserid);
  
    // Update a highlights with id
    router.put("/:id", highlights.update);
  
    // Delete a highlights with id
    router.delete("/:id", highlights.delete);
  
    // Delete all highlightss
    router.delete("/", highlights.deleteAll);
  
    app.use('/api/highlights', router);
  };