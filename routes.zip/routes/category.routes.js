module.exports = app => {

    const category = require("../controllers/category.controller.js");
  
    var router = require("express").Router();
  
    // Create a new Event
    // router.post("/", category.create);
  
    // Retrieve all Event
    router.get("/", category.findAll);
  
    // // Retrieve all published users
    // router.get("/published", users.findAllPublished);
  
   // Retrieve a single Category with id
    router.get("/:Category_Id", category.findOne);
  
    // // Update a Event with id
    // router.put("/:Category_Id", category.update);
  
    // // Delete a Event with id
    // router.delete("/:Category_Id", category.delete);
  
    // // Delete all events
    // router.delete("/", category.deleteAll);
  
    app.use('/api/category', router);
  };