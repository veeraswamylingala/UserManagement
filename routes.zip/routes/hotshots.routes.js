

module.exports = app => {

  
    const hotshots = require("../controllers/hotshots.controller");
  
    var router = require("express").Router();
  
    // Create a new commentry
    router.post("/", hotshots.create);

  
    // Retrieve all commentry

    router.get("/",hotshots.findAll);
  
    // // Retrieve all published users
    // router.get("/published", users.findAllPublished);
  

    router.get("/:Id",hotshots.findOne);
   
  
    // Update a commentry with id
    router.put("/:Id",hotshots.update);
    
  
    // Delete a commentry with id
    router.delete("/:Id",hotshots.delete);
    
  
    // Delete all commentrys
    router.delete("/", hotshots.deleteAll);
  
    app.use('/api/hotshots', router);
  };