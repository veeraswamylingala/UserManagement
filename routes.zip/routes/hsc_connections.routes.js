module.exports = app => {

  
    const hsc_connections = require("../controllers/hsc_connections.controller");
  
    var router = require("express").Router();
  
    // Create a new hsc_connections
    router.post("/", hsc_connections.create);
  
    // Retrieve all hsc_connections
    router.get("/", hsc_connections.findAll);
  
    // // Retrieve all published users
    // router.get("/published", users.findAllPublished);
  
    // Retrieve a single hsc_connectionss with id
    router.get("/:id", hsc_connections.findOne);
  
    // Update a hsc_connections with id
    router.put("/:id", hsc_connections.update);
  
    // Delete a hsc_connections with id
    router.delete("/:id", hsc_connections.delete);
  
    // Delete all hsc_connectionss
    router.delete("/", hsc_connections.deleteAll);
  
    app.use('/api/hsc_connections', router);
  };