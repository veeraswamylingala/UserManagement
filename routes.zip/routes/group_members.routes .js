module.exports = app => {
    const group_members = require("../controllers/group_members.controller");
    const multer = require('multer')
  
    var router = require("express").Router();
  
    // Create a new group_member
    router.post("/", group_members.create);
  
    // Retrieve all group_members
    router.get("/", group_members.findAll);
  
    // // Retrieve all published group_members
    // router.get("/published", users.findAllPublished);
  
    // Retrieve a single group_member with id
    router.get("/:member_id", group_members.findOne);
  
    // Update a group_member with id
    router.put("/:member_id", group_members.update);
  
    // Delete a group_member with id
    router.delete("/:member_id", group_members.delete);
  
    // Delete all group_members
    router.delete("/", group_members.deleteAll);
  
    app.use('/api/group_members', router);

    //handle storage using multer
// var storage = multer.diskStorage({
//   destination: function (req, file, cb) {
//     cb(null,"app/images")
//   },
//   filename: function (req, file, cb) {
//     cb(null,file.originalname)
//   }

// });


// var upload = multer({ storage: storage });
// // // handle single file upload

// //app.use('/Profile_Pic',express.static('images'));
// router.post("/", upload.single('Profile_Pic'), users.create);
// app.post('/users', upload.single('file'), (req, res, next) => {
//   console.log("enterd into image upload")
//   const file = req.file;
//   if (!file) {
//      return res.status(400).send({ message: 'Please upload a file.' });
//   }
//   console.log(req.file.filename)
//       res.send({
//         data:req.file.filename
//       })
// });
  };