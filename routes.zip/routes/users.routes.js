module.exports = app => {
    const users = require("../controllers/users.controller.js");
    const multer = require('multer')
  
    var router = require("express").Router();
  
    // Create a new User
    router.post("/", users.create);
  
    // Retrieve all users
    router.get("/", users.findAll);
  
    // // Retrieve all published users
    // router.get("/published", users.findAllPublished);
  
    // Retrieve a single User with id
    router.get("/:User_Id", users.findOne);
  
    // Update a User with id
    router.put("/:User_Id", users.update);
  
    // Delete a USer with id
    router.delete("/:User_Id", users.delete);
  
    // Delete all users
    router.delete("/", users.deleteAll);
  
    app.use('/api/users', router);

    //handle storage using multer
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null,"app/images")
  },
  filename: function (req, file, cb) {
    cb(null,file.originalname)
  }

});


var upload = multer({ storage: storage });
// // handle single file upload

//app.use('/Profile_Pic',express.static('images'));
router.post("/", upload.single('Profile_Pic'), users.create);
// app.post('/users', upload.single('file'), (req, res, next) => {
//   console.log("enterd into image upload")
//   const file = req.file;
//   if (!file) {
//      return res.status(400).send({ message: 'Please upload a file.' });
//   }
//   console.log(req.file.filename)
//       res.send({
//         data:req.file.filename
//       })
// });
  };