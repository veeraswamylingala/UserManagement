module.exports = app => {

  
    const innerjoin = require("../controllers/innerjoin.controller");
  
    var router = require("express").Router();
  
   
  
    // Retrieve all hotshots
    router.get("/", innerjoin.findAll);
  
   
  
    app.use('/api/innerjoin', router);
  };