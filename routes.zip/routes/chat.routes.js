module.exports = app => {

  
    const chat = require("../controllers/chat.controller");
  
    var router = require("express").Router();
  
    // Create a new chat
    router.post("/", chat.create);
  
    // Retrieve all chat
    router.get("/", chat.findAll);
  
    // // Retrieve all published users
    // router.get("/published", users.findAllPublished);
  
    // Retrieve a single chats with id
    router.get("/:Chat_Id", chat.findOne);
  
    // Update a chat with id
    router.put("/:Chat_Id", chat.update);
  
    // Delete a chat with id
    router.delete("/:Chat_Id", chat.delete);
  
    // Delete all chats
    router.delete("/", chat.deleteAll);
  
    app.use('/api/chat', router);
  };