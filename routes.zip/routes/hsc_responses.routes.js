module.exports = app => {

  
  const hsc_responses = require("../controllers/hsc_responses.controller");

  var router = require("express").Router();

  // Create a new hsc_responses
  router.post("/", hsc_responses.create);

  // Retrieve all hsc_responses
  router.get("/", hsc_responses.findAll);

  //Update Particual fileds
  router.post("/updatevideostreamfields/:Stream_Id", hsc_responses.updateparticularfields);

  // Retrieve a single hsc_responsess with UserId
  router.get("/findAllusersWithUserId/:user_id", hsc_responses.findAllWithUserId);

  // Retrieve a single hsc_responsess with id
  router.get("/:id", hsc_responses.findOne);

   // Retrieve a single hsc_responsess and hot,like,Dislike  with StreamDI
   router.get("/field/:Stream_Id", hsc_responses.findtworesponses );

  // Update a hsc_responses with id
  router.put("/:id", hsc_responses.update);

  // Delete a hsc_responses with id
  router.delete("/:id", hsc_responses.delete);

  // Delete all hsc_responsess
  router.delete("/", hsc_responses.deleteAll);

  app.use('/api/hsc_responses', router);
};