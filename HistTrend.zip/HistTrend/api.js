//var Db  = require('./dboperations');
//var Order = require('./order');

var config = require('./dbconfig');
const sql = require('mssql');

const dboperations = require('./dboperations');

const socketIo = require("socket.io");

const http = require("http");

const server = http.createServer(app);


let port = process.env.PORT || 8090;
server.listen(port, () => console.log(`Listening on port ${port}`));

var express = require('express');
const cron = require("node-cron");
var bodyParser = require('body-parser');
var cors = require('cors');
var app = express();
var router = express.Router();
var mexp = require('math-expression-evaluator');



app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
app.use('/api', router);


router.use((request,response,next)=>{
   console.log('middleware');
   next();
})

app.get("/", (req, res) => {
   res.json({ message: "Welcome to ECSCADA application." });
 });

router.route('/orders').get((request,response)=>{

   console.log("rajkumar..enterd")

    dboperations.getOrders().then(result => {
      // console.log(result)
       response.json(result[0]);
       
    })

})

router.route('/orders/:id').get((request,response)=>{

    dboperations.getOrder(request.params.id).then(result => {
       response.json(result[0]);
    })

})

router.route('/orders').post((request,response)=>{

    let order = {...request.body}

    dboperations.addOrder(order).then(result => {
       response.status(201).json(result);
    })

})


// cron.schedule("*/10 * * * * *", function() {
//    console.log("running a task every 10 second");
   

//    console.log("rajkumar..enterd")

//     dboperations.getOrders().then(result => {
//       // console.log(result)
//        //response.json(result[0]);
       
//     })
// });

const io = socketIo(server);


let interval;

io.on("connection", (socket) => {
   console.log("New Client CONNECTED");

   socket.on("off", () => {
      console.log("Client disconnected");
      clearInterval(interval);
     socket.disconnect();
    });
  //console.log("New client connected");

  socket.on("FromAPI", (value) => {
   console.log("Client FromApi connected");
   console.log(value)


  if(interval)
  {
     clearInterval(interval);
  }

 // interval =  setInterval(function A() { 
     //console.log("conected to timer")
      var handshakeData = socket.request;
    //  console.log(handshakeData);
      console.log("middleware:",value['my']);
      //next();
      // connect to your database
      if(value!= undefined)
      {
      try{
                 
      sql.connect(config, function (err) {
      
        if (err)
        {

         console.log(err);
         const response = {"data":"null",
         "error":"true" }  ;
         socket.emit("FromAPI", response);
       
        } else{

      // create Request object
        var request = new sql.Request();

        //console.log("entered into sql")

       let quer2 = `select '_'+pointname as pointname,fvalue from WEBDATA;`
       request.query(quer2, function (err, recordset) {

         if(recordset != undefined){
          let dt = recordset.recordset
        

         // console.log(dt)
       
        //var temp = (handshakeData._query['foo'])
        var temp =   value['my']
       //_DTms_0003+2+_DTms_0004/_DTms_0005
      console.log(temp)
       //console.log("dgshfh",dt.length)
       
            b = temp.toString();
            for (let i = 0; i < dt.length; i++)
            {
                var TagName = dt[i]["pointname"].toString();
                var fvalue = dt[i]["fvalue"].toString();
                if (temp.toString().includes(TagName))
                {
                 // console.log(TagName)
                 // console.log(fvalue)
                 // console.log(b)
                    b =  b.replace(TagName, fvalue);
                    temp = b.toString();
                    //console.log(temp)
                }
            }
            console.log(temp)
            console.log(eval(temp))
           result = eval(temp)
               if(result != undefined){
               const response = {"data":result.toString(),
                               "error":"false" }  ;
                               socket.emit("FromAPI", response);    
                              }
         } })

         
       } })
         // .catch((err),{
         //    const response = {"data":"null",
         //    "error":"true" }  ;
         //    socket.emit("FromAPI", response);
   
         // })
      }
      catch{

         const response = {"data":"null",
         "error":"true" }  ;
         socket.emit("FromAPI", response);

      }
   }else{
      console.log("value undefined")
   }
               

         //    }


           // console.log(result !)
         //    const response = {"data":temp.toString(),
         //                     "error":"false" }   

         //  socket.emit("FromAPI", response);              
      
      


 
      //      let query1 =`SELECT fvalue FROM WEBDATA WHERE pointname='${handshakeData._query['foo']}';`
      //     // console.log(query1)
      //   // query to the database and get the records
      //   request.query(query1, function (err, recordset) {
            
      //       if (err) console.log(err)
  
      //       // send records as a response
      //      //console.log("rajkumar",recordset.recordset[0].fvalue);
  
      //      const response = {"data":recordset.recordset[0].fvalue.toString(),
      //                        "error":"false" }              
       
  
      //                //console.log(response)
      //                var response1 = 10;
      //                var response2 = 2;
      //                var exp = response1+32/response2;
      //               // console.log("exp value",exp)
      //                //var value = mexp.eval(exp);  
      //                //console.log(value)
      
      //        // socket.emit("FromAPI", response);
      //   });
  
        
    
  
    //var response = res.data
   // console.log(response)
    // Emitting a new message. Will be consumed by the client
   // socket.emit("FromAPI", response);

  // }, 1000); 
});

})

 //getApiAndEmit(socket)
//   if (interval) {
//     clearInterval(interval);
//   }
//   //interval = setInterval(() => getApiAndEmit(socket), 1000);
//   socket.on("disconnect", () => {
//     console.log("Client disconnected");
//     clearInterval(interval);
//   });
  
  
//   //clearInterval(interval);
// });

// const getApiAndEmit = socket => {

//   io.use(function(socket, next) {
//     var handshakeData = socket.request;
//     //console.log("middleware:", handshakeData._query['foo']);
//     next();
//     // connect to your database
//     sql.connect(config, function (err) {
    
//       if (err) console.log(err);

//       // create Request object
//       var request = new sql.Request();
//          let query1 =`SELECT fvalue FROM WEBDATA WHERE pointname='${handshakeData._query['foo']}';`
//          //.log(query1)
//       // query to the database and get the records
//       request.query(query1, function (err, recordset) {
          
//           if (err) console.log(err)

//           // send records as a response
//          //console.log("rajkumar",recordset.recordset[0].fvalue);

//          const response = {"data":recordset.recordset[0].fvalue.toString(),
//                            "error":"false"        }              
     

//       console.log(response)
    
//       //socket.emit("FromAPI", response);
//       });

      
//   });

//   //var response = res.data
//  // console.log(response)
//   // Emitting a new message. Will be consumed by the client
//  // socket.emit("FromAPI", response);

// });


//  };


//  io.sockets.on('connection',  (socket) =>  {
//   //socket.emit('greeting', 'Hello');

//   var handshakeData = socket.request;
//   console.log("middleware:", handshakeData._query['foo']);
//   setInterval(5000,getApiAndEmit = socket => {
//     io.use(function(socket, next) {
     
//       next();
//       // connect to your database
//       sql.connect(config, function (err) {
      
//         if (err) console.log(err);
  
//         // create Request object
//         var request = new sql.Request();
//            let query1 =`SELECT fvalue FROM WEBDATA WHERE pointname='${handshakeData._query['foo']}';`
//            //.log(query1)
//         // query to the database and get the records
//         request.query(query1, function (err, recordset) {
            
//             if (err) console.log(err)
  
//             // send records as a response
//            //console.log("rajkumar",recordset.recordset[0].fvalue);
  
//            const response = {"data":recordset.recordset[0].fvalue.toString(),
//                              "error":"false"        }              
       
  
//         console.log(response)
      
//         socket.emit("FromAPI", response);
//         });
  
        
//     });
  
//     //var response = res.data
//    // console.log(response)
//     // Emitting a new message. Will be consumed by the client
//    // socket.emit("FromAPI", response);
  
//   });


//   });
// });





