

export const datalist =(data)=>{
    return {
      type:'datalist',
      payload: data
    }
  }
  
  export const chartoption =(data)=>{
    return {
      type:'chartoption',
      payload: data
    }
  }

