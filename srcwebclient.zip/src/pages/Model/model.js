import { useState } from "react";
import axios from "axios";
import React from "react";
import Sketch from "@uiw/react-color-sketch";
import Github from "@uiw/react-color-github";
import { Button, Modal } from "react-bootstrap";
import "./modal.css"
import { color } from "highcharts";

class MyVerticallyCenteredModal extends React.Component {
  constructor(props) {
    super(props);

    this.state = {

      upperValue: "",
      lowerValue: "",
      color: null,

    };

    
  }

 
  //UpperValue----
  upperValueHandler = (e) => {
    this.setState({ upperValue: e.target.value });
  };

  //LowerValue
  lowerValueHandler = (e) => {
    this.setState({ lowerValue: e.target.value });
  };

  colorHandler = (e) => {};

  //Save
  handlevalidation =()=>{

      let validValue = false;
      if (parseFloat(this.state.upperValue) > parseFloat(this.state.lowerValue)){ 
        validValue = true;      
      }
    console.log(validValue)
    return validValue;

  }


  
  save = () => {

    // console.log(this.state.color)
    // console.log(this.state.upperValue)
    // console.log(this.state.lowerValue)

    var validValue = this.handlevalidation();
    console.log(validValue)
  //   if ( validValue == false) {
  //     alert("Upper value sholud be greater than Lower value")

  // }
 //  if(validValue == true){
    this.props.onSave({
      upperValue:  this.state.upperValue == null ?this.props.tagData["upperValue"]  :this.state.upperValue,
      lowerValue:this.state.lowerValue == null ?this.props.tagData["lowerValue"]  :this.state.lowerValue,
      axisIndex: this.props.tagData["axisIndex"],
      color: this.state.color == null ?this.props.tagData["color"]  :this.state.color,
    });


    this.setState({
      upperValue:null,
      lowerValue:null,
      color :null
    })
  //}
  };



  // hide = () =>{


  //   this.setState({
  //     upperValue:null,
  //     lowerValue:null,
  //     color :null
  //   },()=>{
  //     this.props.onHide

  //   })
  
  // }

  render() {
    return (
    
      <div  >   
      <Modal
  
        show={this.props.show}
        onHide={this.props.onHide}
        animation={false}
        fade={true}
        backdrop="false"
        style={{marginLeft:"700px",marginTop:"200px"}}

        size="small"
        centered
      >
        <Modal.Header >
          <Modal.Title>
            {" "}
            {this.props.tagData["axisIndex"] + 1}{". "}
            {this.props.tagData["tagName"] }
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div class="form-group">
            UpperValue
            <input
              type="text"
              class="form-control"
              placeholder={this.props.tagData["upperValue"]}
              onChange={(e) => this.upperValueHandler(e)}
            />
          </div>
          <div class="form-group">
            LowerValue
            <input
              type="text"
              class="form-control"
              placeholder={this.props.tagData["lowerValue"]}
              onChange={(e) => this.lowerValueHandler(e)}
            />
          </div>
          <div class="row">
            <label for="inputEmail">Select Pen Color : </label> &nbsp; &nbsp;
            {/* <Button style={{background:this.state.color}} onClick={this.props.onHide}>
          
          </Button> */}
            {/* npm i @uiw/react-color-sketch */}
            {/* <Sketch
              style={{ marginLeft: 20 }}
              color={this.props.tagData["color"]}
              onChange={(color) => {
                this.setState({ color: color.hex });
              }}
            /> */}
            {/* npm i @uiw/react-color-github */}
            <Github  style={{background: this.state.color == undefined ?this.props.tagData["color"] : this.state.color }}
              color={this.state.color}
              onChange={(color) => {
                  console.log(color.hex)
                this.setState({ color: color.hex });
              }}
            />
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={this.props.onHide}>
            Close
          </Button>
          <Button variant="primary"  onClick={this.save}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
     
      </div>  
    );
  }
}
export default MyVerticallyCenteredModal;

