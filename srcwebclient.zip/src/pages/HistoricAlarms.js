import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import DateTimeRangeContainer from 'react-advanced-datetimerange-picker'
import { FormControl } from 'react-bootstrap'
import moment from "moment"
import axios from 'axios'
import IP from './Utiltys';

/* import { DateRangePicker } from 'react-dates'; */

import DatetimeRangePicker from 'react-datetime-range-picker';


export class HistoricAlarms extends Component {
  constructor(props) {
    super(props)

    this.state = {
      historicAlarms: [],
      startDate: null,
      EndDate: null,
      selectedFile: null,
      searchInput: "",
      startdateError: "",
      EndDateError: "",
    }
  }


  handleChange = date => {


    this.setState({
      startDate: date
    });
  }
  handleChange1 = date => {


    this.setState({
      EndDate: date
    });
  }
  handleVAlidations() {

    let validStartdate = false;
    let validEndDate = false;
    let validDate = false;
    let validDateRange = false;


    ///.......start date...///
    console.log(this.state.startDate)
    if (this.state.startDate == null) {
      console.log("........entred........")
      validStartdate = true
    }
    ///.......end date...///
    if (this.state.EndDate == null) {
      console.log("........entred........")
      validEndDate = true

    }
    //........end date should be less than start date.........////
    console.log(this.state.EndDate)
    if (this.state.startDate > this.state.EndDate) {

      validDate = true
    }

    ///........ the diffarance beteween the end date and startdate should be Les than 90 days......./////
    if (this.state.startDate && this.state.EndDate !== null) {
      console.log("enterd")
      // To set two dates to two variables
      var date1 = new Date(this.state.startDate);
      var date2 = new Date(this.state.EndDate);
      console.log(date2.getTime())

      // To calculate the time difference of two dates
      var Difference_In_Time = date2.getTime() - date1.getTime();
      console.log(Difference_In_Time)
      // To calculate the no. of days between two dates
      var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
      console.log(Difference_In_Days)
      if (Difference_In_Days >= 91) {
        validDateRange = true
      }
    }
    return { validStartdate, validEndDate, validDate, validDateRange };
  }

  submitHandler = e => {
    e.preventDefault();
    if (this.state.startDate !== null) {
      this.setState({
        startdateError: ""
      }, () => {

      })
    }
    if (this.state.EndDate !== null) {

      this.setState({
        EndDateError: ""
      }, () => {

      })
    }
    var { validStartdate, validEndDate, validDate, validDateRange } = this.handleVAlidations();

    if (validStartdate) {
      // alert("Please Select The Start Date")
      this.setState({

        startdateError: " * Please Select The Start Date"
      }, () => {
        console.log(this.state.startdateError)

      })
    }

    if (validEndDate) {
      //alert("Please Select The End Date")
      this.setState({
        EndDateError: " * Please Select The End Date"
      }, () => {
        console.log(this.state.EndDateError)
      })
    }
    if (validDate) {
      alert("The start date should not be greater than end date")
    }
    if (validDateRange) {
      alert("The start and end date should not be greater than 90 days")
    }
    console.log(this.state.startDate)
    const Startdate = moment(this.state.startDate).format('DD-MMM-YYYY');
    const EndDate = moment(this.state.EndDate).format('DD-MMM-YYYY');

    const data = { Startdate, EndDate };
    console.log(data)
    if (!validStartdate && !validEndDate && !validDate && !validDateRange) {
      var api = 'http://'+IP+'/ScadaClient/api/HistoricAlarms?StartDate='+ Startdate+'&EndDate='+ EndDate+'&TagName=&Flag=2'
      //var api = 'http://'+IP+'/ScadaClient/api/FileRead?PointName=DAS_GRP2&FromDt='+Startdate+'&ToDt='+EndDate+''
     // var api = 'https://'+IP+':44348/API/HistoricAlarms?StartDate=' + Startdate + '&EndDate=' + EndDate + '&TagName=&Flag=2'
      console.log(api)
      axios.get(api).then(response => {
        console.log(response.data);
        if(response.data.length == 0){
          alert("There is no Alarams between selected date")
          window.location.reload()
      }

        this.setState({
          historicAlarms: response.data
        });
        this.setState({
          selectedFile: response.data
        });

      });
    }
  }
  handleChange2 = e => {
    console.log(e.target.value)
    this.setState({ searchInput: e.target.value }, () => {
      console.log("................")
      this.globalSearch();
    });
  };

  globalSearch = () => {
    let { searchInput } = this.state;
    //console.log( this.state.selectedFile)

    let filteredData = this.state.selectedFile.filter(value => {
      console.log(value.VALUE)
      return (
        value.pointname.toLowerCase().includes(searchInput.toLowerCase()) ||
        value.description.substring(9, 200).toLowerCase().includes(searchInput.toLowerCase()) ||
        value.description.substring(33, 77).toLowerCase().includes(searchInput.toLowerCase()) ||
        value.description.substring(0, 8).toLowerCase().includes(searchInput.toLowerCase()) ||
        value.plantloc.toLowerCase().includes(searchInput.toLowerCase())



      );
    });
    console.log(filteredData)

    this.setState({ historicAlarms: filteredData });


  };

  render() {
    return (
      <body >

        <div >

          <div className="page">

            <div>

              <ul class="nav nav-tabs page-header-tab">
                <li class="nav-item"><Link to="/ViewAlarms" class="nav-link inactive show" data-toggle="tab" href="#Area_Charts">View Alarms</Link></li>

                <li class="nav-item"><Link to="/HistoricAlarms" class="nav-link active show" data-toggle="tab" href="#Email_Settings">Historic Alarms</Link></li>

              </ul>

            </div>



            <div >

              <div className="row clearfix">
                <div className="col-xl-12 col-lg-12">
                  <div className="row">
                  </div>
                  <form onSubmit={this.submitHandler} >
                    <div class="row">
                      <div className="col-md-3 col-sm-12" >
                        Start Date:    <DatePicker
                        style={{ marginLeft: "5px" }}
                          wrapperClassName="datepicker"
                          className="form-control"
                          autoComplete="off"
                          selected={this.state.startDate}
                          onChange={this.handleChange}
                          name="startDate"
                          maxDate={new Date()}
                          dateFormat="MM/dd/yyyy"
                        />
                        <br />
                        <span style={{ fontWeight: "", color: "red" }}>{this.state.startdateError}</span>
                      </div>
                      <div className="col-md-3 col-sm-12" >
                        End Date:   <DatePicker
                          wrapperClassName="datepicker"
                          className="form-control"
                          autoComplete="off"
                          selected={this.state.EndDate}
                          onChange={this.handleChange1}
                          name="EndDate"
                          maxDate={new Date()}
                          dateFormat="MM/dd/yyyy"
                        />
                        <br />
                        <span style={{ fontWeight: "", color: "red" }}>{this.state.EndDateError}</span>
                      </div>
                      <button className="btn btn-primary" type="submit" style={{ height: "35px", background: "blue" }}>Search</button>

                      <input
                        style={{ marginLeft: "490px" }}
                        size="large"
                        name="searchInput"
                        value={this.state.searchInput || ""}
                        onChange={this.handleChange2}
                        placeholder="Search"
                      />
                    </div>


                  </form>
                </div>
              </div>
              <br/>
            </div>
            <div className="tab-content">
              <div className="tab-pane fade show active" id="list" role="tabpanel">
                <div className="row clearfix">
                  <div className="col-lg-12">
                    <div className="table-responsive" id="users" style={{ marginTop: "-20px" }}>
                      <table className="table  table-vcenter text-nowrap table_custom border-style list">
                        <table className="table  ">
                          <thead style={{ textAlign: "left", backgroundColor: "#252d42" }}>
                            <tr>
                              <th style={{ fontSize: "18px", color: "#E5E5E5", fontWeight: 'bold' }}>Date</th>
                              <th style={{ fontSize: "18px", color: "#E5E5E5", fontWeight: 'bold' }}>Time</th>
                              <th style={{ fontSize: "18px", color: "#E5E5E5", fontWeight: 'bold' }}>Device Name</th>
                              <th style={{ fontSize: "18px", color: "#E5E5E5", fontWeight: 'bold' }}>Tag Name</th>
                              <th style={{ fontSize: "18px", color: "#E5E5E5", fontWeight: 'bold' }}>Description</th>
                              <th style={{ fontSize: "18px", color: "#E5E5E5", fontWeight: 'bold' }}>Alm Value</th>
                            </tr>
                          </thead>
                          <tbody>
                            {this.state.historicAlarms.map(historicAlarms => (
                              <tr style={{ backgroundColor: "#252d42" }}>
                                <td className="hidden-xs" style={{ color: "white", width: 30 }}>


                                  {historicAlarms.description.substring(9, 22)}



                                  {/*  <!--<a href="javascript:void(0);" class="mail-star love"><i class="fa fa-heart"></i> --> */}
                                </td>
                                <td className="text-center width40" style={{ color: "white", width: 30 }}>
                                  {/* <!--<div class="avatar d-block">--> */}


                                  {historicAlarms.description.substring(0, 10)}


                                  {/* <!-- <img class="avatar" src="../assets/images/xs/avatar3.jpg" alt="avatar"> --> */}

                                </td>
                                <td style={{ color: "white", width: 30 }}>

                                  {historicAlarms.plantloc}

                                </td>


                                <td className="hidden-xs" style={{ color: "white", width: 30 }}>
                                  {/*  <!-- <div class="text-muted">maryadams@info.com</div>--> */}


                                  {historicAlarms.pointname}


                                </td>

                                <td className="hidden-xs" style={{ color: "white" }}>
                                  {/*  <!-- <div class="text-muted">maryadams@info.com</div>--> */}


                                  {historicAlarms.description.substring(33, 77)}


                                </td>
                                <td class="hidden-xs" style={{ color: "white" }}>
                                  {/*  <!-- <div class="text-muted">maryadams@info.com</div>--> */}

                                  {historicAlarms.description.substring(77, 100)}

                                </td>

                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>

      </body>

    )
  }
}
export default HistoricAlarms;