

var config = require('./dbconfig');
const sql = require('mssql');



async function getOrders() {

    var fs = require("fs")

    let pool = await sql.connect(config);
    console.log(pool)
    
    let Tagname1 = await pool.request().query("SELECT pointname from webdata_log GROUP BY pointname")
    console.log("............................")

     const  Tagname = []
     Tagname1.recordsets.map((a=>{
        Tagname.push(a)
    }))
    console.log(Tagname[0].length)
    

    var filePath = "D:/Unical/DynamicFlatFiles/OutputFolder/"

    // fs.writeFile('data.text', JSON.stringify(fileData), (err) => {

    //     // In case of a error throw err.
    //     if (err) throw err;
    // })
    
    var fs = require('fs');
    const moment = require('moment');
    var time = moment ( new Date()).format("YYYY-MM-DDTHH-mm-ss").toString()
   
    console.log(new Date())
    console.log(time)

            
                    for (let i = 0; i < Tagname[0].length; i++) {

                        let products = await pool.request().query(`select * from webdata_log where pointname ='${Tagname[0][i].pointname}'`);
                        var fileData = JSON.stringify(products.recordsets);
                    
                    fs.open(filePath+Tagname[0][i].pointname+'_'+time+'.txt', 'w', function (err, file) {
                        if (err) throw err;
                        fs.appendFile(filePath+Tagname[0][i].pointname+'_'+time+'.txt', fileData, (err) => {
            
                    // In case of a error throw err.
                    if (err) throw err;
                })
            
                        console.log('Saved!');
                    });
                }
        

            ////////////.......................///
    //     fs.open(filePath+temp+'.txt', 'w', function (err, file) {
    //         if (err) throw err;
    //         fs.writeFile(filePath+temp+'.txt', fileData, (err) => {

    //     // In case of a error throw err.
    //     if (err) throw err;
    // })

    //         console.log('Saved!');
    //     });
        
    return Tagname1.recordsets;


}

module.exports = {
    getOrders: getOrders,

}